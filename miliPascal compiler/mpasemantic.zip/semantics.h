#include "node.h"

typedef enum {type, function, integer, real, error, boolean, string, empty, program} basic_type;

typedef struct _scope scope;
typedef struct _variavel variavel;

struct _scope 
{
	variavel *varList;
	int nivel;
	scope *next;
	scope *pai;
};

struct _variavel 
{
	char* nome;
	basic_type tipo;
	char* flag;
	char* valor;
	variavel* next;
	scope *funcao;
};

/*Funcao para converter em minusculas*/
char *toLower(char*);

/*Funcoes de verificacao*/
int checkProgram(node_ptr);
int checkVarPart(node_ptr);
int checkFuncPart(node_ptr);
int checkStatPart(node_ptr);
int checkVarDecl(node_ptr);
int checkFuncDecl(node_ptr);
int checkFuncDef(node_ptr);
int checkFuncDef2(node_ptr);
int checkFuncParams(node_ptr);
void print_error(int tipo, int line, int col, char *token, char *type, char *type2, int num);

//--Statements--//
int checkAssign(node_ptr);
int checkWriteLn(node_ptr);
int checkCall(node_ptr);
int checkIfElse (node_ptr);
int checkRepeat (node_ptr);
int checkStatList (node_ptr);
int checkWhile (node_ptr);
int checkValParam(node_ptr);

basic_type evalExpr(node_ptr);
basic_type typeName(node_ptr no, int flag);

/*Funcoes do semantics que chamam funcoes do symbols*/
int registerFunc(node_ptr, basic_type, char*);
int checkNewVariable(node_ptr, basic_type);
int checkParam(node_ptr);
int checkVarParam(node_ptr);
basic_type checkTable(node_ptr);

/*Funcoes do symbols*/
variavel *createVar(char* name, basic_type typo, char* flage, char* value, scope *func);
variavel *insertVar(char* value, basic_type tipo, scope* cur);
scope *createOuter();
scope *createFunctionTable(char* name, basic_type typo, scope* dad);
scope *insertFuncDecl(char* nome, basic_type tipo, scope* prog, char*, int, int) ;
void printTables (scope*);
int insertParam (scope* func, char* nome, basic_type tipo, char* flage) ;
int countFuncParams(scope *func);
variavel *lookupFun(char *name, scope *prog);
variavel *lookupVar(char *name, scope *prog);

void argNumber(int line, int col, char* token, int n1, int n2);