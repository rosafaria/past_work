#include "semantics.h"
#include <ctype.h>

char *tipos[9] = {"_type_", "_function_", "_integer_", "_real_", "_error_", "_boolean_", "_string_", "_empty_", "_program_"};
char *titulos[3] = {"===== Outer Symbol Table =====", "===== Program Symbol Table =====","===== Function Symbol Table ====="};
scope *fila;

variavel *createVar(char* name, basic_type typo, char* flage, char* value, scope *func) 
{
	variavel * nova = (variavel*) malloc(sizeof(variavel));
	nova->nome = toLower(name);
	nova->tipo = typo;
	nova->flag = flage;
	nova->valor = value;
	nova->next = NULL;
	nova->funcao = func;
    
    return nova;
}

/* verificar se variável já está declarada antes */
variavel* lookupVar( char* name, scope* cur )
{
    variavel* aux = cur->varList;
            
    for ( ; aux ; aux=aux->next )
        if ( !strcmp(toLower(aux->nome), toLower(name)) ) return aux;
    
    return NULL;
}

/* inserir nova variável no scope passado como argumento */
variavel *insertVar(char * value, basic_type tipo, scope* cur) 
{
	variavel *aux = cur->varList;
    
	if (aux == NULL)  
    {
		cur->varList = createVar(value, tipo, NULL, NULL, NULL);
		return cur->varList;
	}
      
    if ( lookupVar(value,cur) != NULL )
        return NULL;
        
	while (aux->next !=NULL)
		aux = aux->next;
    
	aux->next = createVar(value, tipo, NULL, NULL, NULL);
	return aux->next;
}

int insertParam (scope *func, char *nome, basic_type tipo, char *flage) 
{
    variavel* aux;
    
	if ( ( aux= insertVar(nome, tipo, func) ) == NULL ) return 0;
    
	aux->flag = flage;
	return 1;
}

/*usar so na declaracao*/
variavel *lookupFun(char *name, scope *prog) 
{
	variavel *aux = prog->varList;
	while (aux!=NULL) {
		if (strcmp(toLower(aux->nome), toLower(name))==0) return aux;
		aux = aux->next;
	}
	return NULL;
}


int countFuncParams(scope *func) {
	int i = 0;
	if (func == NULL || func->varList == NULL) return -1;
	variavel *aux = func->varList->next;
	while (aux!=NULL) {
		if (aux->flag == NULL || (strcmp(aux->flag, "param") != 0 && strcmp(aux->flag, "varparam") != 0)) break;
		aux = aux->next; i++;
	}
	return i;
}

scope *insertFuncDecl(char *nome, basic_type tipo, scope *prog, char * flage, int line, int col) 
{
	variavel *aux = lookupFun(nome, prog);
	
	if (aux != NULL && (aux->flag == NULL || (aux->flag!=NULL && (strcmp(flage, "2")==0 || strcmp(aux->flag,"0")!=0 || strcmp(flage,"0") == 0)))) {
		print_error(6,line,col,nome,NULL,NULL,0);
		return NULL;
	}
	else if (aux!=NULL) aux->flag = "1";
	if (aux == NULL && strcmp(flage, "1")==0) {
		print_error(7,line,col,nome,NULL,NULL,0);
		return NULL;
	}
	if (aux == NULL) {
		aux = insertVar(nome, function, prog);
		aux->flag = flage;
		aux->funcao = createFunctionTable(nome, tipo, prog);
	}
	return aux->funcao;
}

scope *createFunctionTable(char * name, basic_type typo, scope *dad) 
{
	scope *novo = (scope*) malloc(sizeof(scope));
	novo->next = NULL;
	novo->nivel = 2;
	novo->pai = dad;
	novo->varList = createVar(name, typo, "return", NULL, NULL);
	return novo;
}

scope *createProgramTable(scope *outer) 
{
	scope *novo = (scope*) malloc(sizeof(scope));
	novo->next = NULL;
	novo->nivel = 1;
	novo->pai = outer;
	novo->varList = NULL;
    
    return novo;
}

scope *createOuter() 
{
	scope *outer = (scope*) malloc(sizeof(scope));
	outer->next = NULL;
	outer->nivel = 0;
	outer->pai = NULL;
	outer->varList = createVar("boolean",type, "constant","_boolean_", NULL);
	variavel *aux = outer->varList;
	aux->next = createVar("integer",type, "constant","_integer_", NULL);
	aux = aux->next;
	aux->next = createVar("real",type, "constant","_real_", NULL);
	aux = aux->next;
	aux->next = createVar("false",boolean, "constant","_false_", NULL);
	aux = aux->next;
	aux->next = createVar("true",boolean, "constant","_true_", NULL);
	aux = aux->next;
	aux->next = createVar("paramcount",function, NULL,NULL, createFunctionTable("paramcount",integer, outer));
	aux = aux->next;
	aux->next = createVar("program",program, NULL,NULL, createProgramTable(outer));
	return outer;
}


/*IMPRIMIR COISAS*/
void addFila (scope *novinha) 
{
	if (fila == NULL) {
		fila = novinha;
		return;
	}
	scope *aux = fila;
	while (aux->next !=NULL) aux = aux->next;
	aux->next = novinha;
}

void printVar(variavel *varia) 
{
	printf("%s",varia->nome);
	printf("\t%s",tipos[varia->tipo]);
	if (varia->flag!=NULL && strlen(varia->flag) > 2) printf("\t%s",varia->flag);
	if (varia->valor !=NULL) printf("\t%s",varia->valor);
	if (varia->funcao !=NULL) addFila(varia->funcao);
}

void printTable(scope *root)
{
    variavel *aux = root->varList;
	printf("%s",titulos[root->nivel]);
	while (aux!=NULL) 
    {
		printf("\n");
		printVar(aux);
		aux = aux->next;
	}
	printf("\n");
}

void printTables (scope *root) 
{
	printTable(root);
	while (fila!=NULL) 
    {
		printf("\n");
		printTable(fila);
		fila = fila->next;
	}
}



