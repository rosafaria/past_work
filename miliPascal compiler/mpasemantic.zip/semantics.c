#include "semantics.h"
#include <ctype.h>

char *tipoStr[9] = {"_type_", "_function_", "_integer_", "_real_", "_error_", "_boolean_", "_string_", "_empty_", "_program_"};
scope *outer;
scope *programNode;
scope *cur;
basic_type funcAux = error;

variavel* checkTable2(node_ptr no) {
	variavel *aux2 = lookupVar(no->value, cur );
	if (aux2==NULL && cur!=programNode) aux2 = lookupVar(no->value, programNode);
	if (aux2==NULL && cur!=outer) aux2 = lookupVar(no->value, outer);
	return aux2;
}

char *toLower(char *str) 
{	
	char *aux = strdup(str);
	int i,a = strlen(str);
    
	for (i = 0; i<a; i++)
		aux[i] = tolower(aux[i]);
	
    aux[a] = '\0';
	return aux;
}

int checkNode (node_ptr no, char* name, int children) 
{
	if (no == NULL || strcmp(no->type,name)!=0) return 0;
	if (no->child == NULL | no->child->size <children) return 0;
	return 1;
}

int checkProgram(node_ptr root) 
{
    /* criar scopes */
	outer = createOuter();
	variavel *aux = outer->varList;
	while (aux->next !=NULL) aux = aux->next;
	programNode = aux->funcao;
	cur = programNode;
    
    /* começar a ver a AST */
	if (checkVarPart(root->child->list[1])==0) return 0;
	if (checkFuncPart(root->child->list[2])==0) return 0;
	cur = programNode;
	if (checkStatPart(root->child->list[3])==0) return 0;
	printTables(outer);
    
	return 1;
}

int checkVarPart(node_ptr no) 
{
	if (no == NULL || strcmp(no->type,"VarPart")!=0) return 0;
	if (no->child == NULL || no->child->size == 0) return 1;
	int checking = 1, i = 0;
           
	while (i<no->child->size && checking==1) 
    {
		checking = checkVarDecl(no->child->list[i]);
		i++;
	}
	return checking;
}

int checkVarDecl (node_ptr no) 
{
	if (checkNode(no, "VarDecl",2)==0) return 0;
	basic_type tipo = typeName(no->child->list[no->child->size-1],0);
	if (tipo == error) {
		return 0;
	}
	int checking = 1, i = 0;
	
    while (i<no->child->size-1 && checking==1) 
    {
		checking = checkNewVariable(no->child->list[i], tipo);
		i++;
	}
	return checking;
}

int checkFuncPart(node_ptr no) 
{
	if (no == NULL || strcmp(no->type,"FuncPart")!=0) return 0;
	if (no->child == NULL || no->child->size == 0) return 1;
	int checking = 1, i = 0;
    
	while (i<no->child->size && checking==1) 
    {
		cur = programNode;
		if (no->child->list[i] == NULL) break;
		if (strcmp(no->child->list[i]->type,"FuncDecl") == 0) checking = checkFuncDecl(no->child->list[i]);
		else if (strcmp(no->child->list[i]->type,"FuncDef") == 0) checking = checkFuncDef(no->child->list[i]);
		else if (strcmp(no->child->list[i]->type,"FuncDef2") == 0) checking = checkFuncDef2(no->child->list[i]);
		else return 0;
		i++;
	}
    
    return checking;
}

int checkFuncDecl(node_ptr no) 
{
	if (checkNode(no, "FuncDecl",3)==0) return 0;
	
	/*verificar se o tipo e valido*/
	basic_type tipo = typeName(no->child->list[no->child->size-1], 0);
	if (tipo == error) {
		return 0;
	}
	
	/*criar funcao*/
	if (registerFunc(no->child->list[0], tipo,"0") == 0) return 0;
	
	/*verificar parametros*/
	if (checkFuncParams(no->child->list[1]) == 0) return 0;
	return 1;
}

int checkFuncDef(node_ptr no) 
{
	if (checkNode(no, "FuncDef",5)==0) return 0;
	
	/*verificar se o tipo e valido*/
	basic_type tipo = typeName(no->child->list[2], 0);
	if (tipo == error) {
		return 0;
	}
	/*criar funcao*/
	if (registerFunc(no->child->list[0], tipo,"2") == 0) return 0;
        
	/*verificar parametros*/
	if (checkFuncParams(no->child->list[1])==0) return 0;
	
	if (checkVarPart(no->child->list[3])==0) return 0;
    	
	if (checkStatPart(no->child->list[4])==0) return 0;
    
    return 1;
}

int checkFuncDef2(node_ptr no)
{
	if (checkNode(no, "FuncDef2",3)==0) return 0;
	if (registerFunc(no->child->list[0], empty, "1") == 0) return 0;
	if (checkVarPart(no->child->list[1]) == 0) return 0;
	if (checkStatPart(no->child->list[2])==0) return 0;
    
    return 1;
}

int checkFuncParams(node_ptr no) 
{
	if (no == NULL || strcmp(no->type,"FuncParams")!=0) return 0;
	if (no->child == NULL || no->child->size == 0) return 1;
	int i = 0, checking = 1;
    while (i<no->child->size && checking!=0) 
    {
		if (strcmp(no->child->list[i]->type, "Params") == 0) checking = checkParam (no->child->list[i]);
		else if (strcmp(no->child->list[i]->type, "VarParams") == 0) checking = checkVarParam (no->child->list[i]);
		else return 0;
		i++;
	}
    
	return checking;
}

int checkStatPart(node_ptr no) 
{
	if (no == NULL) return 0;
	if (strcmp(no->type,"StatList")==0) return checkStatList(no);
	if (strcmp(no->type,"Assign") == 0) return checkAssign(no);
	if (strcmp(no->type,"IfElse") == 0) return checkIfElse(no);
	if (strcmp(no->type,"Repeat") == 0) return checkRepeat(no);
	if (strcmp(no->type,"ValParam") == 0) return checkValParam(no);
	if (strcmp(no->type,"While") == 0) return checkWhile(no);
	if (strcmp(no->type,"WriteLn") == 0) return checkWriteLn(no);
    return 1;
}

int checkAssign(node_ptr no) 
{
	if (checkNode(no, "Assign",2) == 0) return 0;
	basic_type tipo1, tipo2;
        
	tipo2 = evalExpr(no->child->list[1]);
    if (tipo2 == error) return 0;
	
	variavel *aux2 = lookupVar(no->child->list[0]->value, cur );
    if (aux2==NULL && cur!=programNode) aux2 = lookupVar(no->child->list[0]->value, programNode);
    if ( aux2 == NULL )
    {
        aux2 = lookupVar(no->child->list[0]->value,outer);
        if ( aux2 == NULL )
        {
            print_error(7,no->child->list[0]->linha,no->child->list[0]->coluna,no->child->list[0]->value,NULL,NULL,0);
            return 0;
        }
        else if ( aux2 != NULL && aux2->flag!=NULL && strcmp(aux2->flag, "constant") == 0 )
        {
            print_error(9,no->child->list[0]->linha, no->child->list[0]->coluna, NULL, NULL, NULL, 0);
		    return 0;
        }
    }
        
	tipo1 = checkTable(no->child->list[0]);
	
    if (tipo1 == function) 
    {
		print_error(9,no->child->list[0]->linha, no->child->list[0]->coluna, NULL, NULL, NULL, 0);
		return 0;
	}
	
    if (tipo1!=tipo2 &&!(tipo1 == real && tipo2 == integer)) 
    {
		print_error(4,no->child->list[1]->linha,no->child->list[1]->coluna,no->child->list[0]->value,tipoStr[tipo2], tipoStr[tipo1],0);
		return 0;
	}
    
	return 1;
}

int checkIfElse (node_ptr no) 
{
	if (checkNode(no, "IfElse",3) == 0) return 0;
	basic_type tipo = evalExpr(no->child->list[0]);
    
	if (tipo == error) return 0;
    
	if (tipo!=boolean) 
    {
		print_error(5,no->child->list[0]->linha,no->child->list[0]->coluna,"if",tipoStr[tipo],"_boolean_",0);
		return 0;
	}

	if (checkStatPart(no->child->list[1]) == 0) return 0;
	if (checkStatPart(no->child->list[2]) == 0) return 0;
	return 1;
}

int checkWhile (node_ptr no) 
{
	if (checkNode(no, "While",2) == 0) return 0;
    
	basic_type tipo = evalExpr(no->child->list[0]);
	
	if (tipo == error) return 0;
    	
	if (tipo!=boolean) 
    {
		print_error(5,no->child->list[0]->linha,no->child->list[0]->coluna,"while",tipoStr[tipo],"_boolean_",0);
		return 0;
	}
	if (checkStatPart(no->child->list[1]) == 0) return 0;
	return 1;
}

int checkRepeat (node_ptr no) 
{    
	if (checkNode(no, "Repeat",2) == 0) return 0;
	if (checkStatPart(no->child->list[0]) == 0) return 0;
        
	basic_type tipo = evalExpr(no->child->list[1]);
    	
	if (tipo == error) return 0;
	if (tipo!=boolean) 
    {
		print_error(5,no->child->list[1]->linha,no->child->list[1]->coluna,"repeat-until",tipoStr[tipo],"_boolean_",0);
		return 0;
	}
	return 1;
}

int checkStatList (node_ptr no) 
{
	if (no == NULL || strcmp(no->type,"StatList")!=0) return 0;
            
	if (no->child == NULL || no->child->size == 0) return 1;
    
	int checking = 1, i = 0;
	while (i<no->child->size && checking==1) {
		checking = checkStatPart(no->child->list[i]);
		i++;
	}
	return checking;
}

int checkEmptyCall(node_ptr no) 
{
	if (no == NULL) return 0;
	
	/*Procurar funcao*/
	variavel *aux = lookupFun(no->value, programNode);
	if (aux == NULL) aux = lookupFun(no->value, outer);
	if (aux == NULL) { //Symbol not defined
		print_error(7,no->linha, no->coluna, no->value, NULL, NULL, 0);
		return 0;
	}
	
	if (aux->funcao == NULL || aux->funcao->varList == NULL) { //Function identifier expected
		print_error(2,no->linha, no->coluna, NULL, NULL, NULL, 0);
		return 0;
	}
	
	scope *funcaoCall = aux->funcao;
	if (funcaoCall->varList!=NULL && funcaoCall->varList->tipo!=error) {
		funcAux = funcaoCall->varList->tipo;
		if (funcAux == error) return 0;
	}
	/*Verificar nº de filhos*/
	int num = countFuncParams(funcaoCall);
	
	if (num == -1) return 0;
	if (num != 0)  { //Wrong number of arguments
		argNumber(no->linha, no->coluna, no->value, 0, num);
		return 0;
	}
	
	return 1;
}

int checkCall(node_ptr no) 
{
	if (checkNode(no, "Call", 1)==0) return 0;
	
	/*Procurar funcao*/
	variavel *aux = lookupFun(no->child->list[0]->value, programNode);
	if (aux == NULL) aux = lookupFun(no->child->list[0]->value, outer);
	if (aux == NULL) { //Symbol not defined
		print_error(7,no->child->list[0]->linha, no->child->list[0]->coluna, no->child->list[0]->value, NULL, NULL, 0);
		return 0;
	}
	
	if (aux->funcao == NULL || aux->funcao->varList == NULL) { //Function identifier expected
		print_error(2,no->child->list[0]->linha, no->child->list[0]->coluna, NULL, NULL, NULL, 0);
		return 0;
	}
	
	scope *funcaoCall = aux->funcao;
	if (funcaoCall->varList!=NULL && funcaoCall->varList->tipo!=error) 
    {
		funcAux = funcaoCall->varList->tipo;
		if (funcAux == error) return 0;
	}
	
	/*Verificar nº de filhos*/
	int num = countFuncParams(funcaoCall);
	if (num == -1) return 0;
	if (num != no->child->size-1)  { //Wrong number of arguments
		argNumber(no->child->list[0]->linha, no->child->list[0]->coluna, no->child->list[0]->value, no->child->size-1, num);
		return 0;
	}
	if (num == 0) return 1; // Nao tem filhos, devolve ja
	/*verificar tipos de filhos*/
	int i = 0;
	aux = funcaoCall->varList->next;
	basic_type tipo1, tipo2;
	
	while (aux!=NULL && i<num) {
		if (no->child->list[i+1] == NULL) break;
		
		/*Verificar se e passagem por referencia*/
		if (strcmp(aux->flag,"varparam") == 0) {
				variavel *aux2 = lookupVar(no->child->list[i+1]->value, cur );
				if (aux2==NULL && cur!=programNode) aux2 = lookupVar(no->child->list[i+1]->value, programNode);
				if (aux2==NULL && cur!=outer) aux2 = lookupVar(no->child->list[i+1]->value, outer);
				if (aux2 == NULL || (aux2!=NULL && aux2->flag!=NULL && strcmp(aux2->flag, "constant") == 0)) {
					print_error(9,no->child->list[i+1]->linha, no->child->list[i+1]->coluna, NULL, NULL, NULL, 0);
					return 0;
				}
		}
		else {
			tipo1 = aux->tipo;
			if (tipo1 == error || tipo1 == empty) return 0; //ERRO?
			
			tipo2 = evalExpr(no->child->list[i+1]);
			if (tipo2 == error || tipo2 == empty) return 0; //ERRO?
			
			if (tipo1 !=tipo2 && !(tipo1 == real && tipo2 == integer)) {
				print_error(3,no->child->list[i+1]->linha, no->child->list[i+1]->coluna, no->child->list[0]->value, tipoStr[tipo2], tipoStr[tipo1],i+1);
				return 0;
			}
		}
		aux = aux->next; i++;
	}
	
	return 1;
}

basic_type evalExpr(node_ptr no) 
{
	if (no == NULL) return error;
	if (no->child == NULL || no->child->size == 0) /*terminal*/
    {
	
		if (strcmp(no->type,"IntLit")==0) return integer;
		if (strcmp(no->type,"RealLit")==0) return real;
		if (strcmp(no->type,"String")==0) return string;
		if (strcmp(no->type,"Id")==0) {
			variavel* aux3 = checkTable2(no);
			basic_type tipo = checkTable(no);
			if (aux3!=NULL && aux3->flag!=NULL && strcmp(aux3->flag,"return")==0) { //esta a chamar-se a si própria
				if(checkEmptyCall(no) == 0) {
					return error;
				}
				else {
					return aux3->tipo;
				}
			}
			else if (tipo == function) {
				if(checkEmptyCall(no) == 0) {
					return error;
				}
				else {
					return funcAux;
				}
			}
			if (tipo == error) print_error(7,no->linha, no->coluna, no->value,NULL,NULL,0);
			return tipo;
		}
        return error;
	}
    
	else 
    {			
		/*Call*/
		if (strcmp(no->type,"Call")==0) 
        {
			if (checkCall(no) == 0) return error;
			else return funcAux;
		}
		
		/*obter tipo dos filhos*/
		basic_type tipo1, tipo2;
		if (no->child->size>0) {
			tipo1 = evalExpr(no->child->list[0]);
			if (tipo1 == error) return;
		}
		if (no->child->size>1) {
			tipo2 = evalExpr(no->child->list[1]);
			if (tipo2 == error) return;
		}
		
		/*Reais ou inteiros com sinal*/
		if (strcmp(no->type,"Minus")==0 || strcmp(no->type,"Plus")==0) 
        {
			if (tipo1 == integer || tipo1 == real)
				return tipo1;
			else 
            {
				print_error(11,no->linha,no->coluna,no->value, tipoStr[tipo1],NULL,0);
				return error;
			}
		}
		
		/*Mod e div - so inteiros*/
		if (strcmp(no->type,"Mod")==0 || strcmp(no->type,"Div")==0) 
        {
			if (tipo1 == integer && tipo2 == integer)
				return integer;
			else {
				print_error(12,no->linha,no->coluna,no->value, tipoStr[tipo1],tipoStr[tipo2],0);
				return error;
			}
		}
		
		/*Divisao real devolve sempre real*/
		if (strcmp(no->type,"RealDiv")==0) {
			if ((tipo1==integer||tipo1 == real) && (tipo2 == integer||tipo2 == real))
				return real;
			
			else {
				print_error(12,no->linha,no->coluna,"/", tipoStr[tipo1],tipoStr[tipo2],0);
				return error;
			}
		}
		
		/*Soma, sub e multiplicacao - depende dos termos*/
		if (strcmp(no->type,"Add")==0||strcmp(no->type,"Sub")==0||
			strcmp(no->type,"Mul")==0) {
			if (tipo1 == integer){
				if(tipo2 == integer) return integer;
				else if (tipo2 == real) return real;
				else {
					print_error(12,no->linha,no->coluna,no->value, tipoStr[tipo1],tipoStr[tipo2],0);
					return error;
				}
			}
			else if (tipo1 == real) {
				if (tipo2 != real && tipo2!=integer) {
					print_error(12,no->linha,no->coluna,no->value, tipoStr[tipo1],tipoStr[tipo2],0);
					return error;
				}
				else return real;
			}
			else {
				print_error(12,no->linha,no->coluna,no->value, tipoStr[tipo1],tipoStr[tipo2],0);
				return error;
			}
		}
		/*Comparadores*/
		if (strcmp(no->type,"Neq")==0||strcmp(no->type,"Eq")==0||
			strcmp(no->type,"Geq")==0||strcmp(no->type,"Gt")==0||
			strcmp(no->type,"Lt")==0||strcmp(no->type,"Leq")==0) {
			if (((tipo1==integer||tipo1 == real) && (tipo2 == integer||tipo2 == real) )||(tipo1 ==boolean && tipo2 == boolean)) {
				return boolean;
			}
			else {
				print_error(12,no->linha,no->coluna,no->value, tipoStr[tipo1],tipoStr[tipo2],0);
				return error;
			}
		}
		
		/*And, or e not*/
		if (strcmp(no->type,"And")==0||strcmp(no->type,"Or")==0) 
        {
			if ((tipo1 == boolean && tipo2 == boolean)) {
				return boolean;
			}
			else {
				print_error(12,no->linha,no->coluna,no->value, tipoStr[tipo1],tipoStr[tipo2],0);
				return error;
			}
		}
		
		if (strcmp(no->type,"Not")==0) {
			if (tipo1 == boolean) {
				return boolean;
			}
			else {
				print_error(11,no->linha,no->coluna,no->value, tipoStr[tipo1],NULL,0);
				return error;
			}
		}
		
		return error;
	}
}

int checkNewVariable(node_ptr no, basic_type tipo) 
{
	if ( insertVar(no->value, tipo, cur) == NULL )
    {
        print_error(6,no->linha,no->coluna,no->value,NULL,NULL,0);
        return 0;
    }
        
    return 1;
}

int registerFunc(node_ptr no, basic_type tipo, char*flag) 
{
	cur = insertFuncDecl(no->value, tipo, programNode, flag, no->linha, no->coluna);
	if (cur == NULL) return 0;
	return 1;
}

basic_type checkTable(node_ptr no) 
{
    /* procurar id no scope actual */
    variavel* aux = cur->varList;
    for ( ; aux ; aux = aux->next )
    {
        if ( strcmp(toLower(no->value),aux->nome) == 0 )
            return aux->tipo;
    }
	
	aux = programNode->varList;
    for ( ; aux ; aux = aux->next )
    {
        if ( strcmp(toLower(no->value),aux->nome) == 0 )
            return aux->tipo;
    }
	
	aux = outer->varList;
    for ( ; aux ; aux = aux->next )
    {
        if ( strcmp(toLower(no->value),aux->nome) == 0 )
            return aux->tipo;
    }
	
    
	return error;
}

int checkParam(node_ptr no) 
{
	if (checkNode(no, "Params",2)==0) return 0;
	basic_type tipo = typeName(no->child->list[no->child->size-1],0);
	int i;
	
    if (tipo == error){
		return 0;
	}
    
	for (i = 0; i<no->child->size-1;i++)
		if (insertParam (cur, no->child->list[i]->value, tipo, "param") == 0) 
        {
            print_error(6,no->child->list[i]->linha,no->child->list[i]->coluna,no->child->list[i]->value,NULL,NULL,0);
			return 0;
		}
	
	return 1;
}

int checkVarParam(node_ptr no) 
{
	if (checkNode(no, "VarParams",2)==0) return 0;
	basic_type tipo = typeName(no->child->list[no->child->size-1],0);
	if (tipo == error) {
		return 0;
	}
	
	int i;
	for (i = 0; i<no->child->size-1;i++)
		if (insertParam (cur, no->child->list[i]->value, tipo, "varparam") == 0) 
        {
			print_error(6,no->child->list[i]->linha,no->child->list[i]->coluna,no->child->list[i]->value,NULL,NULL,0);
			return 0;
		}
	
	return 1;
}

int checkWriteLn(node_ptr no) 
{
	if (no == NULL || strcmp(no->type,"WriteLn")!=0) return 0;
	if (no->child == NULL || no->child->size == 0) return 1;
	int i;
    
	for (i = 0; i<no->child->size; i++) 
    {
		basic_type tipo = evalExpr(no->child->list[i]);
		if (tipo == error) {
			return 0;
		}
		
		if (tipo == type) 
        {
			print_error(1,no->child->list[i]->linha,no->child->list[i]->coluna,NULL, NULL, NULL,0);
			return 0;
		}
	}
	return 1;
}

int checkValParam(node_ptr no) 
{
	if (checkNode(no, "ValParam",2)==0) return 0;
	basic_type tipo = evalExpr(no->child->list[0]);
	if (tipo == error) return 0;
	
	variavel *aux2 = lookupVar(no->child->list[0]->value, cur );
	if (aux2==NULL && cur!=programNode) aux2 = lookupVar(no->child->list[0]->value, programNode);
	if ((aux2!=NULL && aux2->flag!=NULL && strcmp(aux2->flag, "constant") == 0)) {
		print_error(9,no->child->list[0]->linha, no->child->list[0]->coluna, NULL, NULL, NULL, 0);
		return 0;
	}
	
	if (tipo!=integer) {
		print_error(5,no->child->list[0]->linha,no->child->list[0]->coluna,"val-paramstr",tipoStr[tipo],"_integer_",0);
		return 0;
	}
	
	tipo = checkTable(no->child->list[1]);
	if (tipo == error) {
		print_error(7,no->child->list[1]->linha,no->child->list[1]->coluna,no->child->list[1]->value,NULL,NULL,0);
		return 0;
	}
	
	if (tipo!=integer) {
		print_error(5,no->child->list[1]->linha,no->child->list[1]->coluna,"val-paramstr",tipoStr[tipo],"_integer_",0);
		return 0;
	}
	
	return 1;
}

basic_type typeName(node_ptr no, int flag) 
{
	if (no->value == NULL || strcmp(no->value,"")==0) return error;
	basic_type tipo = checkTable(no);
	
	if (tipo == type) {
		char *aux = toLower(no->value);
		if (strcmp(aux, "integer") == 0) return integer;
		if (strcmp(aux, "real") == 0) return real;
		if (strcmp(aux, "boolean") == 0) return boolean;
	}
	
	if (tipo == empty || tipo == error) {
		print_error(7,no->linha,no->coluna,no->value,NULL,NULL,0);
	}
	else if (flag == 0) print_error(8,no->linha,no->coluna,NULL,NULL,NULL,0);
	return error;
}



void print_error(int tipo, int line, int col, char *token, char *type, char *type2, int num) 
{
	switch (tipo) 
    {        
		case 1: 
			printf("Line %i, col %i: Cannot write values of type _type_\n",line, col); break;
		case 2: 
			printf("Line %i, col %i: Function identifier expected\n",line, col); break;
		case 3: 
			printf("Line %i, col %i: Incompatible type for argument %i in call to function %s (got %s, expected %s)\n",line, col, num, token, type, type2); break;
		case 4: 
			printf("Line %i, col %i: Incompatible type in assigment to %s (got %s, expected %s)\n",line, col, token, type, type2); break;
		case 5: 
			printf("Line %i, col %i: Incompatible type in %s statement (got %s, expected %s)\n",line, col, token, type, type2); break;
		case 6: 
			printf("Line %i, col %i: Symbol %s already defined\n",line, col, token); break;
		case 7: 
			printf("Line %i, col %i: Symbol %s not defined\n",line, col, token); break;
		case 8: 
			printf("Line %i, col %i: Type identifier expected\n",line, col); break;
		case 9: 
			printf("Line %i, col %i: Variable identifier expected\n",line, col); break;
		case 11:
			printf("Line %i, col %i: Operator %s cannot be applied to type %s\n",line, col, token, type); break;
		case 12:
			printf("Line %i, col %i: Operator %s cannot be applied to types %s, %s\n",line, col, token, type, type2); break;
	}
}

void argNumber(int line, int col, char* token, int n1, int n2) 
{
	printf("Line %i, col %i: Wrong number of arguments in call to function %s (got %i, expected %i)\n",line, col, token, n1, n2);
}