#include <stdlib.h>
#include <string.h>
#include <stdio.h>

typedef struct node* node_ptr;
typedef struct _node_list_t node_list_t;
    
typedef struct node
{
	node_list_t * child;
	char *value;
	char *type;
}tree_node;

struct _node_list_t 
{ 
    node_ptr* list; 
    int size; 
};

/*Funcao que devolve um novo no com tipo e lista de filhos dados*/
node_ptr mknode(char *tipo, node_list_t* filhos);

/*Funcao que devolve um novo no so com tipo, sem valor e sem filhos*/
node_ptr mk_node_empty (char *tipo);

/*Funcao que devolve novo no-folha, com tipo e valor, sem filhos*/ 
node_ptr mk_leaf(char *tipo, char *valor);

/*Funcao que devolve no com 5 filhos*/
node_ptr mk_node_5(char *tipo, node_ptr filho1, node_ptr filho2, node_ptr filho3, node_ptr filho4, node_ptr filho5);

/*Funcao que devolve no com 4 filhos*/
node_ptr mk_node_4(char *tipo, node_ptr filho1, node_ptr filho2, node_ptr filho3, node_ptr filho4);

/*Funcao que devolve no com 3 filhos*/
node_ptr mk_node_3(char *tipo, node_ptr filho1, node_ptr filho2, node_ptr filho3);

/*Funcao que devolve no com 2 filhos*/
node_ptr mk_node_2(char *tipo, node_ptr filho1, node_ptr filho2);

/*Funcao que devolve no com 1 filho*/
node_ptr mk_node_1(char *tipo, node_ptr filho);

/*Funcao que devolve nova lista que inclui a anterior e o novo no inicio*/
node_list_t* add_listBegin ( node_list_t* list, node_ptr novo);

/*Funcao que devolve nova lista que inclui a anterior e o novo no fim*/
node_list_t* add_list (node_list_t* list, node_ptr novo);

/*Funcao que devolve nova lista com novo no inicio e novo2 no fim*/
node_list_t* add_list2 (node_list_t* list, node_ptr novo, node_ptr novo2);

/*Funcao para imprimir lista*/
void print_tree (int level, node_ptr root);

/*Verifica se o no e superfluo*/
node_ptr superfluous (char *tipo, node_ptr primeiro, node_list_t* filhos);

/*Devolve no vazio statlist se no for nulo*/
node_ptr isEmpty (node_ptr no);
