#include "semantics.h"
#include <ctype.h>

char *tipos[9] = {"_type_", "_function_", "_integer_", "_real_", "_error_", "_boolean_", "_string_", "_empty_", "_program_"};
char *titulos[3] = {"===== Outer Symbol Table =====", "===== Program Symbol Table =====","===== Function Symbol Table ====="};
scope *fila;


/*criar nova estrutura com nova variavel*/
variavel *createVar(char* name, basic_type typo, char* flage, char* value, scope* func) 
{
	variavel * nova = (variavel*) malloc(sizeof(variavel));
	nova->nome = toLower(name);
	nova->tipo = typo;
	nova->flag = flage;
	nova->valor = value;
	nova->next = NULL;
	nova->funcao = func;
    nova->llnome = NULL;
    
    return nova;
}

/** verificar se variável já está declarada antes **/
/********* retorna ponteiro para variável **********/
variavel* lookupVar( char* name, scope* cur )
{
    variavel* aux = cur->varList;
    for ( ; aux ; aux=aux->next )
	   if ( !compareLower(aux->nome, name) )
		  return aux;

    return NULL;
}

/** inserir nova variável no scope passado como argumento **/
/************* retorna ponteiro para variável **************/
variavel *insertVar(char * value, basic_type tipo, scope* cur) 
{
	variavel *aux = cur->varList;
    
	if (aux == NULL)  
    {
		cur->varList = createVar(value, tipo, NULL, NULL, NULL);
        cur->varList->llnome = NULL;
        
        if (cur->nivel!=0)
        {
            char* novo = (char*) malloc(strlen(value)+3);
            if (cur->nivel == 1) 
			if (tipo == function) 
				sprintf(novo,"@.%s\0",value);
			else
				sprintf(novo,"@_%s\0",value);
            else if (cur->nivel == 2) sprintf(novo,"%%%s\0",value);

            cur->varList->llnome = novo;
        }
        return cur->varList;
	}
      
    if (lookupVar(value,cur) != NULL) return NULL;
            
	while (aux->next !=NULL) aux = aux->next;
    
	aux->next = createVar(value, tipo, NULL, NULL, NULL);
	    
	if (cur->nivel == 0) aux->next->llnome = NULL;	
	
    else 
    {
		char* novo = (char*) malloc(strlen(value)+3);
		if (cur->nivel == 1) {
			if (tipo == function) 
				sprintf(novo,"@.%s\0",value);
			else
				sprintf(novo,"@_%s\0",value);
		}
		else if (cur->nivel == 2) sprintf(novo,"%%%s\0",value);
        
		aux->next->llnome = novo;
	}
	return aux->next;
}

/** inserir parametro no scope da funcao como param ou varparam**/
int insertParam (scope *func, char *nome, basic_type tipo, char *flage) 
{
    	variavel* aux;
    
	if ( ( aux= insertVar(nome, tipo, func) ) == NULL ) return 0;
    
	aux->flag = flage;
	return 1;
}

/** retorna numero de parametros no scope passado como argumento **/
int countFuncParams(scope *func) {
	int i = 0;
	if (func == NULL || func->varList == NULL) return -1;
	variavel *aux = func->varList->next;
	while (aux!=NULL) {
		if (aux->flag == NULL || (strcmp(aux->flag, "param") != 0 && strcmp(aux->flag, "varparam") != 0)) break;
		aux = aux->next; i++;
	}
	return i;
}

/** inserir nova funcao - verifica se existe e se pode ser declarada **/
/********** retorna ponteiro para funcao se bem sucedido **************/
scope *insertFuncDecl(char *nome, basic_type tipo, scope *prog, char * flage, int line, int col) 
{
	variavel *aux = lookupVar(nome, prog);
	
	/*funcao existe e ja foi completamente declarada ou estamos a tentar declarar com funcDef uma que ja foi declarada como funcDecl*/
	if (aux != NULL && (aux->flag == NULL || (aux->flag!=NULL && (strcmp(flage, "2")==0 || strcmp(aux->flag,"0")!=0 || strcmp(flage,"0") == 0)))) 
    {
		print_error(6,line,col,nome,NULL,NULL,0); /*symbol already defined*/
		return NULL;
	}
    
	else if (aux!=NULL) aux->flag = "1"; /*funcao existe e pode ser definida com funcdef2*/

	if (aux == NULL && strcmp(flage, "1")==0) { /*funcao nao existe e estamos a tentar definir sem declarar - symbol not defined*/
		print_error(7,line,col,nome,NULL,NULL,0);
		return NULL;
	}

	if (aux == NULL) { /*funcao nao existe e esta a ser declarada*/
		aux = insertVar(nome, function, prog);
		aux->flag = flage;
		aux->funcao = createFunctionTable(nome, tipo, prog);
	}
    
	return aux->funcao;
}

/** cria novo scope e devolve ponteiro para ele **/
scope *createFunctionTable(char * name, basic_type tipo, scope *dad) 
{
	scope *novo = (scope*) malloc(sizeof(scope));
	novo->next = NULL;
	novo->nextFila = NULL;
	novo->nivel = 2;
	novo->pai = dad;
	novo->varList = createVar(name, tipo, "return", NULL, NULL);
	return novo;
}

/** cria scope do programa e devolve ponteiro para ele **/
scope *createProgramTable(scope *outer) 
{
	scope *novo = (scope*) malloc(sizeof(scope));
	novo->next = NULL;
	novo->nextFila = NULL;
	novo->nivel = 1;
	novo->pai = outer;
	novo->varList = NULL;
    
    return novo;
}

/** cria outer scope com variaveis pre-definidas **/
scope *createOuter() 
{
	scope *outer = (scope*) malloc(sizeof(scope));
	outer->next = NULL;
	outer->nivel = 0;
	outer->pai = NULL;
	outer->varList = createVar("boolean",type, "constant","_boolean_", NULL);
	variavel *aux = outer->varList;
	aux->next = createVar("integer",type, "constant","_integer_", NULL);
	aux = aux->next;
	aux->next = createVar("real",type, "constant","_real_", NULL);
	aux = aux->next;
	aux->next = createVar("false",boolean, "constant","_false_", NULL);
	aux = aux->next;
	aux->next = createVar("true",boolean, "constant","_true_", NULL);
	aux = aux->next;
	aux->next = createVar("paramcount",function, NULL,NULL, createFunctionTable("paramcount",integer, outer));
	aux->next->llnome = "@..paramcount";
	aux = aux->next;
	aux->next = createVar("program",program, NULL,NULL, createProgramTable(outer));
	return outer;
}

/*IMPRIMIR COISAS*/
void addFila (scope *novinha) 
{
	if (fila == NULL) {
		fila = novinha;
		return;
	}
	scope *aux = fila;
	while (aux->nextFila !=NULL) {aux = aux->nextFila;}
	aux->nextFila = novinha;
}

void printVar(variavel *varia) 
{
	printf("%s",varia->nome);
	printf("\t%s",tipos[varia->tipo]);
	if (varia->flag!=NULL && strlen(varia->flag) > 2) printf("\t%s",varia->flag);
	if (varia->valor !=NULL) printf("\t%s",varia->valor);
	if (varia->funcao !=NULL) addFila(varia->funcao);
	//DEBUUUUUUUUUUUUUUUUUUUUG
	
	if (varia->llnome!=NULL) printf("\t%s",varia->llnome);
}

void printTable(scope *root)
{
    variavel *aux = root->varList;
	printf("%s",titulos[root->nivel]);
	while (aux!=NULL) 
    	{
		printf("\n");
		printVar(aux);
		aux = aux->next;
	}
	printf("\n");
}

void printTables (scope *root) 
{
	printTable(root);
	while (fila!=NULL) 
    	{
		printf("\n");
		printTable(fila);
		scope *aux = fila;
		fila = fila->nextFila;
		aux->nextFila = NULL;
	}
}


/***** LIMPAR MEMORIA *****/
void freeVar(variavel *varia) 
{
	if (varia->nome!=NULL) free(varia->nome);
	if (varia->funcao !=NULL) addFila(varia->funcao);
}

void freeTable(scope *root) 
{
	if (root==NULL || root->varList == NULL) return;
	variavel *aux = root->varList;
	variavel *aux2;
	while (aux!=NULL) 
    	{	
		freeVar(aux);
		aux2 = aux;
		aux = aux->next;
		free(aux2);
	}
}

void freeTables (scope *root) 
{
	fila = NULL;
	freeTable(root);
	free(root);
	scope *aux;
	while (fila!=NULL) 
    	{
		freeTable(fila);
		aux = fila;
		fila = fila->nextFila;
		free(aux);
	}
}
