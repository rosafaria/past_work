#include "semantics.h"

char* giveName(char* header, char* value);
char* getNextTempVariable();
char* getNextLabelName();

void generateMain();
void genParamcountFunction();
void genProgram(node_ptr root);
void printHeader();
void printStringHeader();

void genVarPart(node_ptr no, int global);
void newIntegerVariable( char* nome );
void newBooleanVariable( char* nome );
void newRealVariable( char* nome);
void genVarDeclGlobal(node_ptr no);
void genVarDeclLocal(node_ptr no);

void genFuncPart(node_ptr);
void genFuncDef(node_ptr, int);

void genStatPart( node_ptr no );
void genValParam( node_ptr no );
void genWriteLn( node_ptr no );
void genAssign( node_ptr no );
void genEvalExpression( node_ptr no );
void genWhile(node_ptr no);
void genRepeat(node_ptr no);
void genIfElse(node_ptr no);
void genPlusMinus(node_ptr, char*);
void genRealDiv(node_ptr);
void genAddSubMul(node_ptr, char*);
void genDivMod(node_ptr, char*);
void genNot(node_ptr);
void genAndOr(node_ptr, char*);
void genComp(node_ptr, char*);
void genStatList(node_ptr); 
void genCall(node_ptr);
