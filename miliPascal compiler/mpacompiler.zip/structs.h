#include <stdlib.h>
#include <string.h>
#include <stdio.h>

typedef enum {type, function, integer, real, error, boolean, string, empty, program} basic_type;
typedef struct _scope scope;
typedef struct _variavel variavel;
typedef struct _opcol opcol;
typedef struct node* node_ptr;
typedef struct _node_list_t node_list_t;
typedef struct _String String;
    
int redParamcount;

typedef struct node
{
	node_list_t * child;
	char *value;
	char *type;
    int linha;
    int coluna;
    char* nome;
    basic_type tipo;
}tree_node;

struct _node_list_t 
{ 
    node_ptr* list; 
    int size; 
};

struct _opcol 
{
    char* op; 
    int col;
    int line;
    char* nome;
};

struct _scope 
{
	variavel *varList;
	int nivel;
	scope *next;
	scope *pai;
	scope *nextFila;
};

struct _variavel 
{
	char* nome;
	basic_type tipo;
	char* flag;
	char* valor;
	variavel* next;
	scope* funcao;
	char* llnome;
};

struct _String
{
    char* print;
    char* nome;
    String* next;
};
