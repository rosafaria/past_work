#include "node.h"


void liberta (opcol* token) 
{
	free(token->op);
	free(token);
	return;
}

node_list_t* createList( int numFilhos )
{
    node_list_t* lista = malloc ( sizeof(node_list_t) );
    lista->size = numFilhos;
    
    if ( numFilhos > 0 )
        lista->list = malloc ( numFilhos * sizeof(node_ptr*) );
    else
        lista->list = NULL;  /* SE NÃO HOUVER FILHOS LISTA FICA NULL */
    
    return lista;                          
}

node_ptr mknode2(char *tipo, node_list_t* filhos, int line, int col, char* valor) 
{
	node_ptr novo = (node_ptr) malloc (sizeof(tree_node));
	novo->value = valor;
	novo->type = tipo;
	novo->child = filhos;
	novo->linha = line;
	novo->coluna = col;
	novo->nome = NULL;
	novo->tipo = empty;
    
	return novo;
}

node_ptr mknode(char *tipo, node_list_t* filhos, char* valor) 
{
	node_ptr novo = (node_ptr) malloc (sizeof(tree_node));
	novo->value = valor;
	novo->type = tipo;
	novo->child = filhos;
	novo->nome = NULL;
	novo->tipo = empty;
	return novo;
}

node_ptr mknodeCall(char *tipo, node_list_t* filhos, int line, int col) 
{
	node_ptr novo = (node_ptr) malloc (sizeof(tree_node));
	novo->type = tipo;
	novo->child = filhos;
	novo->linha = line;
	novo->coluna = col;
	novo->value = NULL;
	novo->nome = NULL;
	novo->tipo = empty;
	return novo;
}

node_ptr mk_node_empty (char *tipo, char* valor) 
{
	node_ptr novo = (node_ptr) malloc (sizeof(tree_node));
	novo->type = tipo;
	novo->value = valor;
	novo->nome = NULL;
	novo->child = NULL;
	return novo;
}

node_ptr mk_leaf(char *tipo, char *valor, int line, int col) 
{
	node_ptr novo = (node_ptr) malloc (sizeof(tree_node));
	novo->value = valor;
	novo->type = tipo;
	novo->child = NULL;
	novo->linha = line;
	novo->coluna = col;
	novo->nome = NULL;
	novo->tipo = empty;
    
	return novo;
}

node_ptr mk_node_5(char *tipo, node_ptr filho1, node_ptr filho2, node_ptr filho3, node_ptr filho4, node_ptr filho5, char* valor) 
{
	node_list_t* filhos = createList(5);
	filhos->list[0] = filho1;
	filhos->list[1] = filho2;
	filhos->list[2] = filho3;
	filhos->list[3] = filho4;
	filhos->list[4] = filho5;
    
	return mknode(tipo, filhos, valor);
}

node_ptr mk_node_4(char *tipo, node_ptr filho1, node_ptr filho2, node_ptr filho3, node_ptr filho4, char* valor) 
{
	node_list_t* filhos = createList(4);
	filhos->list[0] = filho1;
	filhos->list[1] = filho2;
	filhos->list[2] = filho3;
	filhos->list[3] = filho4;
    
	return mknode(tipo, filhos, valor);
}

node_ptr mk_node_3(char *tipo, node_ptr filho1, node_ptr filho2, node_ptr filho3, char* valor) 
{
	node_list_t* filhos = createList(3);
	filhos->list[0] = filho1;
	filhos->list[1] = filho2;
	filhos->list[2] = filho3;
        
	return mknode(tipo, filhos, valor);
}

node_ptr mk_node_2(char *tipo, node_ptr filho1, node_ptr filho2,int linha, int coluna, char* valor) 
{
    node_list_t* filhos = createList(2);
	filhos->list[0] = filho1;
	filhos->list[1] = filho2;
    
	return mknode2(tipo, filhos,linha,coluna, valor);
}

node_ptr mk_node_1(char *tipo, node_ptr filho, int line, int col,char* valor) 
{
    	node_list_t* filhos = createList(1);
	filhos->list[0] = filho;
    
	return mknode2(tipo, filhos, line,col,valor);
}

/*Funcoes para statlist*/

node_ptr superfluous (char *tipo, node_ptr primeiro, node_list_t* filhos) 
{
	if ((filhos == NULL) || (filhos!=NULL && filhos->size <1 ))
		return primeiro;
	if ((primeiro == NULL)&& (filhos!=NULL && filhos->size == 1))
		return filhos->list[0];
	return mknode(tipo, add_listBegin(filhos, primeiro), NULL);
}

node_ptr isEmpty (node_ptr no) 
{
	if (no == NULL)
		return mk_node_empty("StatList", NULL);
	return no;
}

/* adicionar o novo nó ao inicio da lista passada */
node_list_t* add_listBegin ( node_list_t* list, node_ptr novo)
{
	if (list == NULL) 
	{
		list = (node_list_t*) malloc (sizeof(node_list_t));
		list->size = 1;
		list->list = malloc (sizeof(node_ptr));
		list->list[0] = novo;
		return list;
	}
        
	node_ptr *aux = (node_ptr *) malloc( (list->size+1)*sizeof(node_ptr));
	int i,j = 1;

	aux[0] = novo;
    
	for (i = 0; i<list->size; i++)
		aux[j++] = list->list[i];
    
	list->size++;
	free(list->list);
	list->list = aux;

	return list;
}

/* adiciona o novo nó ao final da lista */
node_list_t* add_list (node_list_t* list, node_ptr novo) 
{
	if (novo == NULL) return list;
	if (list == NULL) 
	{
		list = (node_list_t*) malloc (sizeof(node_list_t));
        	list->size = 1;
        	list->list = malloc (sizeof(node_ptr));
		list->list[0] = novo;
		return list;
	}
    
	node_ptr * aux = (node_ptr *) malloc( (++list->size)*sizeof(node_ptr));
	int i ;
    
	for (i = 0; i<list->size-1; i++)
		aux[i] = list->list[i];
    
	aux[i] = novo;
	free(list->list);
	list->list = aux;
    
	return list;
}

node_list_t* add_list2 (node_list_t* list, node_ptr novo, node_ptr novo2) 
{
	if (novo == NULL && novo2 == NULL) return list;
	if (novo == NULL) return add_list(list, novo2);
	if (novo2 == NULL) return add_listBegin(list, novo);
	if (list == NULL) 
    {
		list = (node_list_t *) malloc (sizeof(node_list_t));
        list->list = malloc (2*sizeof(node_ptr));
		list->list[0] = novo;
		list->list[1] = novo2;
        list->size = 2;
		return list;
	}
    
	node_ptr *aux = (node_ptr *) malloc( (list->size+2)*sizeof(node_ptr));
	int i,j = 1;

	aux[0] = novo;
    
	for (i = 0; i<list->size; i++)
		aux[j++] = list->list[i];

	aux[j] = novo2;
    list->size += 2;
    free(list->list);
    list->list = aux;
    
	return list;
}

void print_tree (int level, node_ptr root) 
{
	if (root == NULL) return;
	int i;
    
	for (i = 0; i<level; ++i) 
		printf("..");
	
	if (root->child == NULL) 
    {
        if (root->value!=NULL)
            printf("%s(%s)\n",root->type, root->value);
		else printf("%s\n",root->type);
        return;
	}
    
	printf("%s\n",root->type);
    
	for (i = 0; i<root->child->size;++i)
		print_tree (level+1, root->child->list[i]);
	
	return;
}

void free_tree (node_ptr root) 
{
	if (root == NULL) return;
	if (root->child!=NULL) {
	    int i;
	    for (i = 0; i<root->child->size;++i)
		free_tree (root->child->list[i]);
	    free(root->child->list);
	    free(root->child);
	}
	if (root->value!=NULL) free(root->value);
	free(root);
	return;
}
