#include "llvm.h"

#define SIZE_LABEL      64
#define SIZE_TEMP_VAR   16

unsigned int tempActual=0;
unsigned int labelActual=0;
unsigned int stringActual=0;

char *tipoLL[9] = {"_type_", "_function_", "i32", "double", "_error_", "i1", "i8*", "_empty_", "_program_"};
String* root;
scope* curLL;
int sizeTemp;

char *replace(char *s) 
{
		/*Mais um comentário para o mooshak nao desconfiar que este ficheiro e igual porque ele e so parecido*/
    char*res = s;
	char* ptr = res;
    
    for ( ; *s ; s++ )
    {
        if ( *s == '\'' ) /* se nao é plica, copiamos */
            s++;
        
        *res++ = *s;
    }
    
	*res = '\0';
	
    return ptr;
}

char* giveName(char* header, char* value) 
{    
	char* novo = (char*) malloc(strlen(value)+strlen(header)+1);
	sprintf(novo,"%s%s",header,value);
	return novo;
}

char* getNextTempVariable()
{
    char* next = (char*)malloc(SIZE_TEMP_VAR);
    sprintf(next, "%%.%u", ++tempActual);
    
    return next;
}

char* getNextStringName()
{
    char* next = (char*)malloc(SIZE_TEMP_VAR);
    sprintf(next, "@.str%u", ++stringActual);
    
    return next;
}

char* getNextLabelName() 
{
    char* next = (char*)malloc(SIZE_LABEL);
    sprintf(next, ".label%u", ++labelActual);
    
    return next;
}

void initLinkedList()
{
    String* temp = malloc( sizeof(String) );
    temp->next = NULL;
    temp->nome = NULL;
    temp->print = NULL;
    
    root = temp;
}

/*inicio da geração*/
void genProgram(node_ptr root) 
{
	if (root == NULL || root->child == NULL || root->child->list == NULL) return;
    
	
    initLinkedList();
    
    printHeader();
    
    /* variáveis globais */
    genVarPart(root->child->list[1],1); 
    
    /* paramcount */
    genParamcountFunction();
	
    
    /* funções*/
    genFuncPart(root->child->list[2]);
	curLL = getProgramNode();
    
    /* stat List --> Main */
    generateMain();  
    genStatPart(root->child->list[3]);
        
    printf("ret i32 0\n}\n");
    
    printStringHeader();
}

String* updateLinkedList( char* print , char* n )
{       
    /* lista ainda vazia */
    if ( root->nome == NULL )
    {
        root->nome = n;
        root->print = print;
        return root;
    }
        
    String* temp = root;
        
    while ( temp->next )
            temp = temp->next;
    
    String* nova = malloc(sizeof(String));
    nova->print = print;
    nova->nome = n;
    nova->next = NULL;
    temp->next = nova;
        
    return nova;
}

char* getStringName( char* original )
{
    /* tirar as plicas */
    char* n = malloc(sizeof(original));
    strncpy(n,original+1,strlen(original)-2);
    n[strlen(original)-2] = '\0';
	char* a = replace(n);
    return a;
}

char* newHeaderString( char* name, char* nGlobal )
{   
    char* buffer = malloc(sizeof(char) * 256);
    
    /* tirar as plicas */
    char* n = getStringName(name);
    int size = strlen(n) + 1;
    sizeTemp = size;
    
    sprintf(buffer,"%s = private unnamed_addr constant [%d x i8] c\"%s\\00\"\n",nGlobal,size,n);
        
    return buffer;
}

void generateMain()
{
    printf("\ndefine i32 @main(i32 %%-argc, i8** %%-argv)\n{\n");
    
    char* t1 = getNextTempVariable();
    char* t2 = getNextTempVariable();
    char* t3 = getNextTempVariable();
    char* t4 = getNextTempVariable();    
    
    /* retorno e argumentos ( argc e argv ) */
    printf("%%.ret = alloca i32\n"
           "%s = alloca i32\n"
           "%s = alloca i8**\n", t1, t2);
    
    printf("store i32 %%-argc, i32* %s\n"
           "store i8** %%-argv, i8*** %s\n", t1, t2);
           
    printf("%s = load i32* %s\n"
           "store i32 %s, i32* @.argc\n",t3,t1,t3);
    
    printf("%s = load i8*** %s\n"
           "store i8** %s, i8*** @.argv\n", t4, t2, t4);
}

void genParamcountFunction()
{
    char* t1 = getNextTempVariable();
    char* t2 = getNextTempVariable();
    
    printf("\ndefine i32 @..paramcount()\n{\n"
           "%s = load i32* @.argc\n"
           "%s = sub i32 %s, 1\n"
           "ret i32 %s\n}\n", t1, t2, t1,t2); 
}

/* Cabeçalho do Ficheiro, always the same*/
void printHeader()
{
  printf("declare i32 @printf(i8*, ...)\n"
         "declare i32 @atoi(i8*) nounwind readonly\n"
         "@str.integer_str = private unnamed_addr constant [3 x i8] c\"%%d\\00\"\n"
         "@str.double_str = private unnamed_addr constant [6 x i8] c\"%%.12E\\00\"\n"
         "@str.false_str = private unnamed_addr constant [6 x i8] c\"FALSE\\00\"\n"
         "@str.true_str = private unnamed_addr constant [5 x i8] c\"TRUE\\00\"\n"
		 "@str.par_str = private unnamed_addr constant [2 x i8] c\"\\0A\\00\"\n\n");		 
		 
		 
}

void printStringHeader()
{
    printf("\n");
    
    if ( root->nome == NULL ) return;  /* nao há strings para imprimir */
    
    String* temp = root;
    
    while ( temp )
    {
        printf("%s", temp->print);
        temp = temp->next;
    }
}

void genFuncPart(node_ptr no) 
{
	if (no == NULL || no->child == NULL || no->child->size == 0) return;
	
    int i;
	for (i = 0; i<no->child->size;i++) 
    {
		if (strcmp(no->child->list[i]->type,"FuncDef") == 0) genFuncDef(no->child->list[i],0);
		else if (strcmp(no->child->list[i]->type,"FuncDef2") == 0) genFuncDef(no->child->list[i],2);
	}
}

void genFuncDef(node_ptr no, int flag) 
{        
	/*criar nome da funcao*/
	variavel* aux = checkTable3(no->child->list[0],getProgramNode());
	curLL = aux->funcao;
    
    if ( strcmp(aux->nome,"paramcount")==0 )
        redParamcount=1;
    	
	/* escrever cabecalho */
	variavel* pars = aux->funcao->varList;
    char* nomeTemp = malloc (sizeof(pars->nome) + 1);
	printf("\ndefine %s %s(",tipoLL[pars->tipo], aux->llnome); /* retorno e nome */
    	        
    /* imprimir os parametros da função */
    while(pars->next!=NULL)
	{ 
        if ( pars->next->flag == NULL ) /* nao é parametro */
            break;
        
		pars = pars->next;
		
        char* nomeTemp = malloc (sizeof(pars->nome) + 1);
        sprintf(nomeTemp,"%s%s","%",pars->nome);
        pars->llnome = nomeTemp;
        		
		if (strcmp(pars->flag,"param")==0)
			printf("%s %s",tipoLL[pars->tipo], pars->llnome);
		else 
            printf("%s* %s",tipoLL[pars->tipo], pars->llnome);
                
		if (pars->next!=NULL && pars->next->flag!=NULL &&
			(strcmp(pars->next->flag,"param")==0 || strcmp(pars->next->flag,"varparam")==0) )
			printf(", ");
		else
			break;
	}
    
	printf(")\n{\n");
    	
	/*declarar variaveis retorno e argumentos*/
	printf("%%.ret = alloca %s\n",tipoLL[aux->funcao->varList->tipo]);
    
    pars = aux->funcao->varList;
	pars->llnome = "%.ret";
    
    /* alloca para os parametros */
    while(pars->next!=NULL)
    {
		pars = pars->next;
        if (pars->flag==NULL || (strcmp(pars->flag,"param")!=0 && strcmp(pars->flag,"varparam")!=0) ) break;
        if (strcmp(pars->flag,"param")==0) {
			char* t1 = getNextTempVariable();
			printf("%s = alloca %s\n", t1, tipoLL[pars->tipo]);
			pars->llnome = t1;
		}
    }
    
    /* store dos parametros para as temporarias */
    pars = aux->funcao->varList;
    
    while(pars->next!=NULL)
    {
        pars = pars->next;
		if (pars->flag==NULL || (strcmp(pars->flag,"param")!=0 && strcmp(pars->flag,"varparam")!=0) ) break;
        if (strcmp(pars->flag,"param")==0) {
			sprintf(nomeTemp,"%s%s","%",pars->nome);
			printf("store %s %s, %s* %s\n", tipoLL[pars->tipo], nomeTemp,tipoLL[pars->tipo],pars->llnome);
		}
    }
    printf(";varPart da funcao\n");
	/*gerar varpart e statpart*/
	genVarPart(no->child->list[3-flag], 0);
	genStatPart(no->child->list[4-flag]);
	
	/*retorno*/
	char* tret = getNextTempVariable();
	printf("%s = load %s* %s\n",tret,tipoLL[aux->funcao->varList->tipo],aux->funcao->varList->llnome);
	printf("ret %s %s\n}\n",tipoLL[aux->funcao->varList->tipo],tret);
}

void genStatPart( node_ptr no )
{
	if (no == NULL) return;
    
	printf("\n; %s start\n",no->type);
	if (strcmp(no->type,"StatList")==0)        genStatList(no);
	if (strcmp(no->type,"Assign") == 0)        genAssign(no);
	else if (strcmp(no->type,"IfElse") == 0)   genIfElse(no);
	else if (strcmp(no->type,"Repeat") == 0)   genRepeat(no);
	else if (strcmp(no->type,"While") == 0)    genWhile(no);
    else if (strcmp(no->type,"WriteLn") == 0)  genWriteLn(no);
    else if (strcmp(no->type,"ValParam") == 0) genValParam(no);    
        
	printf("; %s end\n\n",no->type);
}


void genValParam( node_ptr no )
{
    variavel* aux = checkTable3(no->child->list[1],curLL);
	no->child->list[1]->nome = aux->llnome;
	genEvalExpression(no->child->list[0]);
    
    char* t1 = getNextTempVariable();
    char* t3 = getNextTempVariable();
    char* t4 = getNextTempVariable();
    char* t5 = getNextTempVariable();
    
    printf("%s = load i8*** @.argv\n",t1);
    
	char* t6 = getNextTempVariable();
	printf("%s = load i8*** @.argv\n",t6);
    printf("%s = getelementptr inbounds i8** %s, i32 %s\n", t3, t6, no->child->list[0]->nome);
    
    printf("%s = load i8** %s\n"
           "%s = call i32 @atoi(i8* %s)\n", t4, t3, t5, t4);
    
    /* FAZER STORE DO VALOR NA VARIAVEL DA DIREITA */
    printf("store i32 %s, i32* %s\n", t5, no->child->list[1]->nome);
}

void genWriteLn( node_ptr no )
{
    if (no->child != NULL && no->child->size != 0) {
    
		int i;
		
		for ( i=0; i < no->child->size ; i++ )
			genEvalExpression(no->child->list[i]);
		
		for ( i=0; i < no->child->size ; i++ )
		{    
			char* t1 = getNextTempVariable();
					
			switch ( no->child->list[i]->tipo )
			{
				case (string):
					no->tipo = string;
				
					char* nextName = getNextStringName();
					char* newString = newHeaderString(no->child->list[i]->value,nextName);
					String* s= updateLinkedList(newString,nextName);
		   
					printf("call i32 (i8*, ...)* @printf(i8* getelementptr ([%d x i8]* %s, i32 0, i32 0))\n", sizeTemp, s->nome);
				
					break;
				
				case(boolean):
					no->tipo = boolean;
					char* t2 = getNextTempVariable();
					char* t3 = getNextLabelName();
					char* t4 = getNextLabelName();
					char* t5 = getNextLabelName();
				
					printf("%s = icmp eq i1 %s, 1\n",t2,no->child->list[i]->nome);
					printf("br i1 %s, label %%%s, label %%%s\n",t2,t3,t4);
					printf("%s:\n",t3);
					printf("call i32 (i8*, ...)* @printf(i8* getelementptr ([5 x i8]* @str.true_str, i32 0, i32 0))\n");
					printf("br label %%%s\n",t5);
					printf("%s:\n",t4);
					printf("call i32 (i8*, ...)* @printf(i8* getelementptr ([6 x i8]* @str.false_str, i32 0, i32 0))\n");
					printf("br label %%%s\n",t5);
					printf("%s:\n",t5);
					
					break;
									  
				case (integer):
					no->tipo = integer;
					printf("call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([3 x i8]* @str.integer_str, i32 0, i32 0), i32 %s)\n", no->child->list[i]->nome);
					break;
				
				case (real):
					no->tipo = real;
					printf("call i32 (i8*, ...)* @printf(i8* getelementptr inbounds ([6 x i8]* @str.double_str, i32 0, i32 0), double %s)\n", no->child->list[i]->nome);
					break;
				
				default:
					break;
			}
		}
	}
	printf("call i32 (i8*, ...)* @printf(i8* getelementptr ([2 x i8]* @str.par_str, i64 0, i64 0))\n");
}

void genStatList(node_ptr no) 
{
	if (no->child == NULL || no->child->size == 0) return;
	
    int i;
	for (i = 0; i<no->child->size;i++)
		genStatPart(no->child->list[i]);
	return;
}

void genPlusMinus( node_ptr no, char* op )
{
	if (no == NULL || no->child == NULL || no->child->list == NULL) return;
    
    no->nome = getNextTempVariable();
    no->tipo = no->child->list[0]->tipo;
	
	if (no->tipo == real) printf("%s = f%s %s 0.0, %s\n",no->nome,op,tipoLL[no->tipo],no->child->list[0]->nome);
    else printf("%s = %s %s 0, %s\n",no->nome,op,tipoLL[no->tipo],no->child->list[0]->nome);
}

void genAddSubMul( node_ptr no ,char* op)
{
	if (no == NULL || no->child == NULL || no->child->list == NULL) return;
    int flag = 1;
    char* t1;
    char* t2;
    char* t3;
    char* t4;
    char* t5;
    
    no->nome = getNextTempVariable();
           
    switch( no->child->list[0]->tipo )
    {
        case(integer):
            t4 = no->child->list[0]->nome;
            break;
        
        case(real):
            flag = 0;
            t1 = no->child->list[0]->nome;
            break;
        
        default:
            break;
    }
    
    switch( no->child->list[1]->tipo )
    {
        case(integer):
            if ( flag == 0 ) {
				t2 = getNextTempVariable();
                printf("%s = sitofp i32 %s to double\n", t2, no->child->list[1]->nome);
			}
            else
            {
				t2 = no->child->list[1]->nome; 
				t1 = t4;
            }
            
            break;
        
        case(real):
            t2 = no->child->list[1]->nome;
            if ( flag != 0 ) {
				t1 = getNextTempVariable();
                printf("%s = sitofp i32 %s to double\n", t1, t4 );
			}
            flag = 0;
            break;
        
        default:
            break;
    }
    
    switch( flag )
    {
        case(0):
            printf("%s = f%s double %s, %s\n", no->nome, op,t1,t2);
            no->tipo = real;
            break;
        
        case(1):
            printf("%s = %s i32 %s, %s\n", no->nome, op,t1,t2);
            no->tipo = integer;
            break;
        
        default:
            break;
    }
}

void genRealDiv( node_ptr no )
{
	if (no == NULL || no->child == NULL || no->child->list == NULL) return;
    char* t1 = getNextTempVariable();
    char* t2 = getNextTempVariable();
    
    no->nome = getNextTempVariable();
           
    switch( no->child->list[0]->tipo )
    {
        case(integer):
            printf("%s = sitofp i32 %s to double\n",t1, no->child->list[0]->nome);
            break;
        
        case(real):
            t1 = no->child->list[0]->nome;
            break;
        
        default:
            break;
    }
    
    switch( no->child->list[1]->tipo )
    {
        case(integer):
            printf("%s = sitofp i32 %s to double\n",t2, no->child->list[1]->nome);
            break;
        
        case(real):
            t2 = no->child->list[1]->nome;
            break;
        
        default:
            break;
    }
    

    printf("%s = fdiv double %s, %s\n", no->nome, t1,t2);
    no->tipo = real;
}

void genNot( node_ptr no )
{
	if (no == NULL || no->child == NULL || no->child->list == NULL) return;    
    no->nome = getNextTempVariable();
    printf("%s = xor i1 1, %s\n", no->nome,no->child->list[0]->nome);
    no->tipo = boolean;
}

void genAndOr( node_ptr no, char* op )
{
    no->nome = getNextTempVariable();
    printf("%s = %s i1 %s, %s\n",no->nome, op, no->child->list[0]->nome, no->child->list[1]->nome);
    no->tipo = boolean;
}

void genDivMod( node_ptr no, char* op )
{
    char* t1 = getNextTempVariable();
    char* t2 = getNextTempVariable();
    char* t5 = getNextTempVariable();
    
    no->nome = getNextTempVariable();
    
    t1 = no->child->list[0]->nome;
    t2 = no->child->list[1]->nome;
    
    printf("%s = s%s i32 %s, %s\n"
            "%s = alloca i32\n"
            "store i32 %s, i32* %s\n", t5, op, t1,t2,no->nome,t5, no->nome);
    
    no->tipo = integer;
	
	if (strcmp(op,"rem")==0) {	//verificar se e menor que zero, adicionar se for
		char* l1 = getNextLabelName();
		char* l2 = getNextLabelName();
		char* t3 = getNextTempVariable();
		char* t4 = getNextTempVariable();
		
		printf("%s = icmp slt i32 %s, 0\n",t4,t5);
		printf("br i1 %s, label %%%s, label %%%s\n",t4,l1,l2);
		printf("%s:\n",l1);
		printf("%s = add nsw i32 %s, %s\n",t3,t5,t2);
		printf("store i32 %s, i32* %s\n", t3, no->nome);
		printf("br label %%%s\n",l2);
		printf("%s:\n",l2);
	}
	
	char* tres = getNextTempVariable();
	printf("%s = load i32* %s\n",tres,no->nome);
		no->nome = tres;
	return;
}

void genAssign( node_ptr no )
{
	if (no == NULL || no->child == NULL || no->child->list == NULL) return;
    genEvalExpression(no->child->list[1]);
    variavel* aux = checkTable3(no->child->list[0],curLL);
    char* t1 = getNextTempVariable();
        
    no->child->list[0]->nome = aux->llnome;
    no->child->list[0]->tipo = aux->tipo;
	
    switch( no->child->list[0]->tipo )
    {
        case(integer):
            printf("store i32 %s, i32* %s\n", no->child->list[1]->nome, no->child->list[0]->nome);
            break;
        
        case(real):
			if (no->child->list[1]->tipo == integer) 
            {
				printf("%s = sitofp i32 %s to double\n",t1, no->child->list[1]->nome);
			}
            else
				t1 = no->child->list[1]->nome;
             
            printf("store double %s, double* %s \n", t1,no->child->list[0]->nome);
            break;
        
        case(boolean):
            printf("store i1 %s, i1* %s\n", no->child->list[1]->nome,no->child->list[0]->nome);
            break;
        
        default:
            break;       
    }
}

void genComp (node_ptr no, char* op)
{
	if (no == NULL || no->child == NULL || no->child->list == NULL) return;
	
	char* t1 = getNextTempVariable();
    char* t2 = getNextTempVariable();
    no->nome = getNextTempVariable();
	
	if (no->child->list[0]->tipo == boolean) {
		if (strcmp(op,"eq")==0 || strcmp(op,"ne")==0)
			printf("%s = icmp %s i1 %s, %s\n",no->nome,op,no->child->list[1]->nome,no->child->list[0]->nome);
		else 
			printf("%s = icmp s%s i1 %s, %s\n",no->nome,op,no->child->list[1]->nome,no->child->list[0]->nome);
	}
    
	else 
    { //converter os dois para double
		if( no->child->list[0]->tipo == integer)
		{
			printf("%s = sitofp i32 %s to double\n",t1, no->child->list[0]->nome);
			no->child->list[0]->nome = t1;
		}
		
		if( no->child->list[1]->tipo == integer)
		{
			printf("%s = sitofp i32 %s to double\n",t2, no->child->list[1]->nome);
			no->child->list[1]->nome = t2;
		}
		printf("%s = fcmp o%s double %s, %s\n",no->nome,op,no->child->list[0]->nome,no->child->list[1]->nome);
	}
    no->tipo = boolean;
}

void genEvalExpression( node_ptr no )
{
	if (no == NULL) return;
	if (no->child == NULL || no->child->size == 0) /*terminal*/
    {
		if (strcmp(no->type,"IntLit")==0) 
        {
            no->nome = getNextTempVariable();
            no->tipo = integer;
            printf("%s = add i32 0, %s\n",no->nome,no->value);
            return;
		}
        
		if (strcmp(no->type,"RealLit")==0) 
        {
            no->nome = getNextTempVariable();
            no->tipo = real;
			/*verificar expoentes*/
			double banana = atof(no->value);
			
            printf("%s = fadd double 0.0, %f\n",no->nome,banana);
            return;
		}
        
		if (strcmp(no->type,"String")==0)
        {
            no->tipo = string;
            return;
        }
        
		if (strcmp(no->type,"Id")==0) 
        {
			variavel* aux = checkTable3(no, curLL);
			if (aux!=NULL && aux->flag!=NULL && strcmp(aux->flag,"return")==0)
				aux = checkTable3(no,getProgramNode());
			basic_type tipo = aux->tipo;          
            no->tipo = tipo;
            no->nome = getNextTempVariable();
			if (tipo == function) 
			{
				scope* auxS = getFuncScope(no);
				no->tipo = auxS->varList->tipo;
                printf("%s = call %s%s()\n",no->nome,tipoLL[no->tipo],aux->llnome);
				return;
			}
			else
			{
				
				printf("%s = load %s* %s\n",no->nome, tipoLL[tipo],aux->llnome);
			}
		}
    }
    
    /* nao terminal */
    else 
    {
		if (strcmp(no->type,"Call")==0) 
        {
			genCall(no);
			return;
		}
		
		/*gerar	filhos*/
        if ( no->child->list[0] != NULL ) 
            genEvalExpression(no->child->list[0]);
        	
        if ( no->child->size>1 && no->child->list[1] != NULL ) 
            genEvalExpression(no->child->list[1]);
        
        if (strcmp(no->type,"Minus")==0 )
            genPlusMinus(no,"sub");
    
        else if (strcmp(no->type,"Plus")==0 )
            genPlusMinus(no,"add");
        
        else if (strcmp(no->type,"Add")==0 )
            genAddSubMul(no,"add");
        
        else if (strcmp(no->type,"Sub")==0 )
            genAddSubMul(no,"sub");
        
        else if (strcmp(no->type,"Mul")==0 )
            genAddSubMul(no,"mul");
        
        else if (strcmp(no->type,"RealDiv")==0)
            genRealDiv(no);
        
        else if (strcmp(no->type,"Mod")==0 )
            genDivMod(no,"rem");
        
        else if ( strcmp(no->type,"Div")==0)
            genDivMod(no,"div");
        
        else if (strcmp(no->type,"Not")==0)
            genNot(no);
        
        else if (strcmp(no->type,"And")==0)
            genAndOr(no, "and");
        
        else if (strcmp(no->type,"Or")==0)
            genAndOr(no,"or");
        
        else if (strcmp(no->type,"Neq")==0)
			genComp(no,"ne");
		
		else if (strcmp(no->type,"Eq")==0)
			genComp(no, "eq");
			
		else if (strcmp(no->type,"Geq")==0)
			genComp(no,"ge");
		
		else if (strcmp(no->type,"Gt")==0)
			genComp(no,"gt");
		
		else if (strcmp(no->type,"Lt")==0)
			genComp(no,"lt");
		
		else if (strcmp(no->type,"Leq")==0)
			genComp(no,"le");			
    }
}

void genVarPart(node_ptr no, int global )
{   
	if ( global ) /* colocar ainda a global o argumento argv da main, que será o paramcount */
    {
        printf("@.argc = common global i32 0\n");
        printf("@.argv = common global i8** null\n");
		
		/*guardar valores false e true*/
		variavel *aux = boolVar("true");
		aux->llnome = "@.true";
		printf("%s = common global i1 1\n",aux->llnome);
		
		aux = boolVar("false");
		aux->llnome = "@.false";
		printf("%s = common global i1 0\n",aux->llnome);
    }
	
    if (no == NULL || no->child == NULL || no->child->size == 0) return; /*não há variaveis --> valido*/
    int cont=0;
    
    while ( cont < no->child->size )
    {
        if ( global )
            genVarDeclGlobal(no->child->list[cont++]);
            
        else
            genVarDeclLocal(no->child->list[cont++]);
    }
    
    
}

void genVarDeclGlobal( node_ptr no )
{
    if (checkNode(no, "VarDecl",2)==0) return;
    
    int cont;
    
    /* obter tipo das variáveis */
    basic_type tipo = typeName(no->child->list[no->child->size-1],0); /*obter tipo das variaveis a declarar*/
    
    for ( cont=0; cont < no->child->size-1; cont++ )
    {    
        char* nome = giveName("@_",no->child->list[cont]->value);
        no->nome = nome;
        
        no->child->list[cont]->nome = no->nome;
        
        if (tipo == real)
            printf("%s = common global double 0.0\n", nome);
		else
			printf("%s = common global %s 0\n",nome, tipoLL[tipo]);
	}
}

void genVarDeclLocal( node_ptr no )
{
    if (checkNode(no, "VarDecl",2)==0) return;
    
    int cont;
    
    /* obter tipo das variáveis */
    basic_type tipo = typeName(no->child->list[no->child->size-1],0); /*obter tipo das variaveis a declarar*/
    
    for ( cont=0; cont < no->child->size-1; cont++ )
    {
        char* nome = giveName("%",no->child->list[cont]->value);
        no->nome = nome;
        printf("%s = alloca %s\n",nome, tipoLL[tipo]);
	}
}

void genWhile(node_ptr no) 
{
	if (no == NULL || no->child == NULL || no->child->list == NULL) return;
	
    char* l1 = getNextLabelName();
	char* l2 = getNextLabelName();
	char* l3 = getNextLabelName();
	char* t1 = getNextTempVariable();

    printf("br label %%%s\n",l1);
	printf("%s:\n",l1);
	
    genEvalExpression(no->child->list[0]);
	printf("br i1 %s, label %%%s, label %%%s\n", no->child->list[0]->nome, l2,l3);
	printf("%s:\n",l2);
	
    genStatPart(no->child->list[1]);
	printf("br label %%%s\n",l1);
	printf("%s:\n",l3);
    return;
}

void genRepeat(node_ptr no) 
{
	if (no == NULL || no->child == NULL || no->child->list == NULL) return;
	char* l1 = getNextLabelName();
	char* l2 = getNextLabelName();
	char* t1 = getNextTempVariable();	
	printf("br label %%%s\n",l1);
	printf("%s:\n",l1);
	genStatPart(no->child->list[0]);
	genEvalExpression(no->child->list[1]);
	printf("br i1 %s, label %%%s, label %%%s\n", no->child->list[1]->nome, l2,l1);
	printf("%s:\n",l2);
}

void genIfElse(node_ptr no) 
{
	if (no == NULL || no->child == NULL || no->child->list == NULL) return;
	
    char* l1 = getNextLabelName();
	char* l2 = getNextLabelName();
	char* l3 = getNextLabelName();
	genEvalExpression(no->child->list[0]);
    
	printf("br i1 %s, label %%%s, label %%%s\n", no->child->list[0]->nome, l1,l2);
	printf("%s:\n",l1);
	
    genStatPart(no->child->list[1]);	
	printf("br label %%%s\n",l3);
	printf("%s:\n",l2);
	
    genStatPart(no->child->list[2]);	
	printf("br label %%%s\n",l3);
	printf("%s:\n",l3);
	return;
} 

void genCall(node_ptr no) 
{
	if (no == NULL || no->child == NULL || no->child->list == NULL) return;
	int i;
	
	/*procurar funcao na tabela*/
	variavel* aux = checkTable3(no->child->list[0],curLL);
	if (aux->flag!=NULL && strcmp(aux->flag,"return")==0)
		aux = checkTable3(no->child->list[0],curLL->pai);
	no->child->list[0]->nome = aux->llnome;
	
	/*carregar dados funcao*/
	no->nome = getNextTempVariable();
	scope* auxS = getFuncScope(no->child->list[0]);
	no->child->list[0]->tipo = auxS->varList->tipo;
	no->tipo = no->child->list[0]->tipo;
	
	
	variavel* pars = auxS->varList->next;
	/*carregar parametros por valor*/
	for (i = 1; i<no->child->size; i++){
		if (pars->flag!=NULL && strcmp(pars->flag,"param")==0) {
			genEvalExpression(no->child->list[i]);
			if (pars->tipo != no->child->list[i]->tipo) {
				char *tint = getNextTempVariable();
				printf("%s = sitofp i32 %s to double\n",tint, no->child->list[i]->nome);
				no->child->list[i]->tipo = real;
				no->child->list[i]->nome = tint;
			}
		}
		else {
			variavel *temp = checkTable3(no->child->list[i], curLL);
			no->child->list[i]->nome = temp->llnome;
			no->child->list[i]->tipo = temp->tipo;
		}
		pars = pars->next;
	}
	
	
	
	/*gerar inicio da chamada da funcao*/
	printf("%s = call %s%s(",no->nome,tipoLL[no->tipo],aux->llnome);

	pars = auxS->varList->next;
	/*chamar parametros*/
	for (i = 1; i<no->child->size; i++) {
		if (pars->flag!=NULL && strcmp(pars->flag,"param")==0) {
			printf("%s %s",tipoLL[no->child->list[i]->tipo], no->child->list[i]->nome);
		}
		else printf("%s* %s",tipoLL[no->child->list[i]->tipo], no->child->list[i]->nome);
		if (i<no->child->size-1) printf(", ");
		else printf(")\n");
		pars = pars->next;
	}
	
}