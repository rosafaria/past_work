#include "semantics.h"
#include <ctype.h>

char *tipoStr[9] = {"_type_", "_function_", "_integer_", "_real_", "_error_", "_boolean_", "_string_", "_empty_", "_program_"};

scope *outer;
scope *programNode;
scope *cur;
basic_type funcAux = error; /*variavel para guardar tipo da funcao que registamos*/

/*funcoes para comparar strings ignorando case*/
char *toLower(char *str) 
{	
	char *aux = strdup(str);
	int i,a = strlen(str);
    
	for (i = 0; i<a; i++)
		aux[i] = tolower(aux[i]);
	
    	aux[a] = '\0';
	
    return aux;
}

int compareLower(char *str1, char* str2) 
{
	char *aux1 = toLower(str1);
	char *aux2 = toLower(str2);
	int res = strcmp(aux1,aux2);
	return res;
}
/**********************************************/

/*verificar se no e do tipo pretendido e tem o numero de filhos certo*/
int checkNode (node_ptr no, char* name, int children) 
{
	if (no == NULL || strcmp(no->type,name)!=0) return 0;
	if (no->child == NULL | no->child->size <children) return 0;
	return 1;
}

/*inicio da analise semantica*/
int checkProgram(node_ptr root, int print) 
{
    /* criar scopes */
	outer = createOuter();
	variavel *aux = outer->varList;
	while (aux->next !=NULL) aux = aux->next;
	programNode = aux->funcao;
	cur = programNode;
    
    /* começar a ver a AST */
	if (checkVarPart(root->child->list[1])==0) return 0;
	
	if (checkFuncPart(root->child->list[2])==0) return 0;

	cur = programNode; /*indicar que o scope actual é o do program, ja terminaram as funcoes*/
	if (checkStatPart(root->child->list[3])==0) return 0;
	
    if ( print ) printTables(outer);
 
	return 1;
}

/*analise varPart*/
int checkVarPart(node_ptr no) 
{
	if (no == NULL || strcmp(no->type,"VarPart")!=0) return 0;
	if (no->child == NULL || no->child->size == 0) return 1; /*se varPart estiver vazio --> valido*/
	int checking = 1, i = 0;
           
	while (i<no->child->size && checking==1) 
    {
		checking = checkVarDecl(no->child->list[i]);
		i++;
	}
	return checking;
}


int checkVarDecl (node_ptr no) 
{
	if (checkNode(no, "VarDecl",2)==0) return 0;

	basic_type tipo = typeName(no->child->list[no->child->size-1],0); /*obter tipo das variaveis a declarar*/
	if (tipo == error) return 0; /*nao e um tipo valido - erro foi lancado na funcao typeName com flag 0*/

	int checking = 1, i = 0;	
    while (i<no->child->size-1 && checking==1) 
    {
		checking = checkNewVariable(no->child->list[i], tipo);
        
		i++;
	}
	return checking;
}


int checkFuncPart(node_ptr no) 
{
	if (no == NULL || strcmp(no->type,"FuncPart")!=0) return 0;
	if (no->child == NULL || no->child->size == 0) return 1; /*funcPart pode estar vazio*/
	
	int checking = 1, i = 0;    
	while (i<no->child->size && checking==1) 
    {
		cur = programNode;/*actualizar scope, saimos da funcao anterior*/
		if (no->child->list[i] == NULL) break;
		if (strcmp(no->child->list[i]->type,"FuncDecl") == 0) checking = checkFuncDecl(no->child->list[i]);
		else if (strcmp(no->child->list[i]->type,"FuncDef") == 0) checking = checkFuncDef(no->child->list[i]);
		else if (strcmp(no->child->list[i]->type,"FuncDef2") == 0) checking = checkFuncDef2(no->child->list[i]);
		else return 0;
		i++;
	}
    
    	return checking;
}


int checkFuncDecl(node_ptr no) 
{
	if (checkNode(no, "FuncDecl",3)==0) return 0;
	
	/*verificar se o tipo e valido*/
	basic_type tipo = typeName(no->child->list[no->child->size-1], 0);
	if (tipo == error) return 0;

	/*criar funcao*/
	if (registerFunc(no->child->list[0], tipo,"0") == 0) return 0;
	
	/*verificar parametros*/
	if (checkFuncParams(no->child->list[1]) == 0) return 0;
	no->tipo = tipo;
	return 1;
}

int checkFuncDef(node_ptr no) 
{
	if (checkNode(no, "FuncDef",5)==0) return 0;
	
	/*verificar se o tipo e valido*/
	basic_type tipo = typeName(no->child->list[2], 0);
	if (tipo == error) return 0;
	
	/*criar funcao*/
	if (registerFunc(no->child->list[0], tipo,"2") == 0) return 0;
        
	/*verificar parametros*/
	if (checkFuncParams(no->child->list[1])==0) return 0;
	
	/*verificar varPart*/
	if (checkVarPart(no->child->list[3])==0) return 0;
    	
	/*verificar statPart*/
	if (checkStatPart(no->child->list[4])==0) return 0;
    no->tipo = tipo;
    
    return 1;
}

int checkFuncDef2(node_ptr no)
{
	if (checkNode(no, "FuncDef2",3)==0) return 0;
	if (registerFunc(no->child->list[0], empty, "1") == 0) return 0;
	if (checkVarPart(no->child->list[1]) == 0) return 0;
	if (checkStatPart(no->child->list[2])==0) return 0;
    
    return 1;
}

/*tentar inserir parametros na funcao*/
int checkFuncParams(node_ptr no) 
{
	if (no == NULL || strcmp(no->type,"FuncParams")!=0) return 0;
	if (no->child == NULL || no->child->size == 0) return 1;
	int i = 0, checking = 1;
    while (i<no->child->size && checking!=0) 
    {
		if (strcmp(no->child->list[i]->type, "Params") == 0) checking = checkParam (no->child->list[i],"param","Params");
		else if (strcmp(no->child->list[i]->type, "VarParams") == 0) checking = checkParam (no->child->list[i],"varparam","VarParams");
		else return 0;
		i++;
	}
    
	return checking;
}

/*verificar statements*/
int checkStatPart(node_ptr no) 
{
	if (no == NULL) return 0; /*tem de ter pelo menos um no, mesmo que seja statlist vazia*/
	if (strcmp(no->type,"StatList")==0) return checkStatList(no);
	if (strcmp(no->type,"Assign") == 0) return checkAssign(no);
	if (strcmp(no->type,"IfElse") == 0) return checkIfElse(no);
	if (strcmp(no->type,"Repeat") == 0) return checkRepeat(no);
	if (strcmp(no->type,"ValParam") == 0) return checkValParam(no);
	if (strcmp(no->type,"While") == 0) return checkWhile(no);
	if (strcmp(no->type,"WriteLn") == 0) return checkWriteLn(no);
    	return 1;
}


int checkAssign(node_ptr no) 
{
	if (checkNode(no, "Assign",2) == 0) return 0;
	
	basic_type tipo1, tipo2;

	/*avaliar expressao lado direito*/        
	tipo2 = evalExpr(no->child->list[1]);
        
    if (tipo2 == error) return 0;
	
	/*avaliar tipo do primeiro filho*/
	variavel *aux2 = checkTable2(no->child->list[0]);
	
    if ( aux2 == NULL )
	{
    		print_error(7,no->child->list[0]->linha,no->child->list[0]->coluna,no->child->list[0]->value,NULL,NULL,0);
    		return 0;/*nao encontrou simbolo em lado nenhum - symbol not defined*/
	}
	
    else if ( aux2 != NULL && aux2->flag!=NULL && strcmp(aux2->flag, "constant") == 0 )
	{
    		print_error(9,no->child->list[0]->linha, no->child->list[0]->coluna, NULL, NULL, NULL, 0);
	    	return 0; /*encontrou simbolo mas e identificador de tipo - variable identifier expected*/
	}

	tipo1 = aux2->tipo;
    if (tipo1 == function) 
    {
		print_error(9,no->child->list[0]->linha, no->child->list[0]->coluna, NULL, NULL, NULL, 0);
		return 0; /*e funcao - variable identifier expected*/
	}
	
	/*comparar tipo de filhos*/
    if (tipo1!=tipo2 &&!(tipo1 == real && tipo2 == integer)) 
    {
		print_error(4,no->child->list[1]->linha,no->child->list[1]->coluna,no->child->list[0]->value,tipoStr[tipo2], tipoStr[tipo1],0);
		return 0;/*assign nao e valido, tipos nao compativeis - incompatible type in assignment*/
	}
    //GERACAO
	no->child->list[0]->tipo = tipo1;
	//nome auto
	return 1;
}

/*verificar if statement*/
int checkIfElse (node_ptr no) 
{
	if (checkNode(no, "IfElse",3) == 0) return 0;

	/*avaliar condicao*/	
	basic_type tipo = evalExpr(no->child->list[0]);
	if (tipo == error) return 0; /*erro ja foi lancado, a expr nao e valida*/
    
	if (tipo!=boolean) 
    	{
		print_error(5,no->child->list[0]->linha,no->child->list[0]->coluna,"if",tipoStr[tipo],"_boolean_",0);
		return 0; /*incompatible type in if, expected boolean*/
	}

	/*verificar outros filhos*/
	if (checkStatPart(no->child->list[1]) == 0) return 0;
	if (checkStatPart(no->child->list[2]) == 0) return 0;
	return 1;
}

/*verificar while statement*/
int checkWhile (node_ptr no) 
{
	if (checkNode(no, "While",2) == 0) return 0;
    
	/*avaliar condicao*/
	basic_type tipo = evalExpr(no->child->list[0]);
	if (tipo == error) return 0; /*expressao invalida, erro ja lancado*/
    	
	if (tipo!=boolean) 
    	{
		print_error(5,no->child->list[0]->linha,no->child->list[0]->coluna,"while",tipoStr[tipo],"_boolean_",0);
		return 0; /*incompatible type in while, expected boolean*/
	}
	
	/*verificar statPart*/
	if (checkStatPart(no->child->list[1]) == 0) return 0;
	return 1;
}

/*verificar repeat statement*/
int checkRepeat (node_ptr no) 
{    
	if (checkNode(no, "Repeat",2) == 0) return 0;
	/*verificar statPart*/
	if (checkStatPart(no->child->list[0]) == 0) return 0;
        
	/*avaliar condicao*/
	basic_type tipo = evalExpr(no->child->list[1]);
	if (tipo == error) return 0; /*expressao invalida, erro ja foi lancado*/
	if (tipo!=boolean) 
    	{
		print_error(5,no->child->list[1]->linha,no->child->list[1]->coluna,"repeat-until",tipoStr[tipo],"_boolean_",0);
		return 0;/*incompatible type in repeat, expected boolean*/
	}
	return 1;
}

/*verificar statList*/
int checkStatList (node_ptr no) 
{
	if (no == NULL || strcmp(no->type,"StatList")!=0) return 0;
	if (no->child == NULL || no->child->size == 0) return 1; /*pode ser vazia*/
    
	/*iterar sobre os filhos e chamar statPart que vai verificar o tipo de cada um*/
	int checking = 1, i = 0;
	while (i<no->child->size && checking==1) 
	{
		checking = checkStatPart(no->child->list[i]);
		i++;
	}
	return checking;
}

scope* getFuncScope(node_ptr no) 
{
	if (no == NULL) return NULL;
	
	/*Procurar funcao*/
	/*Primeiro no scope do program - todas as funcoes excepto paramcount estao la*/
	variavel *aux = lookupVar(no->value, programNode); 
	
	/*Se nao encontrou, pode ser paramcount --> procurar no outer*/	
	if (aux == NULL) aux = lookupVar(no->value, outer);

	if (aux == NULL) /*Nao encontrou - Symbol not defined*/
	{ 
		print_error(7,no->linha, no->coluna, no->value, NULL, NULL, 0);
		return NULL;
	}
	
	if (aux->funcao == NULL || aux->funcao->varList == NULL) /*Nao e funcao - Function identifier expected*/
	{ 
		print_error(2,no->linha, no->coluna, NULL, NULL, NULL, 0);
		return NULL;
	}
	/*ir para scope da funcao para depois verificar parametros*/
	scope* funcaoCall = aux->funcao;
	if (funcaoCall->varList!=NULL && funcaoCall->varList->tipo!=error) 
	{
		/*guardar tipo da funcao para comparar mais tarde*/
		funcAux = funcaoCall->varList->tipo;
	}
	else return NULL; /*nao deve ocorrer*/

	/*Verificar nº de parametros*/
	return funcaoCall;
}

/*verificar chamada em que apenas esta o id da funcao*/
int checkEmptyCall(node_ptr no) 
{
	scope* funcaoCall = getFuncScope(no);
	int num = countFuncParams(funcaoCall);
	
	if (num == -1) return 0; /*erro ja lancado*/
	if (num != 0) /*Wrong number of arguments*/
	{
		argNumber(no->linha, no->coluna, no->value, 0, num);
		return 0;
	}
	
	return 1;
}

/*verificar chamada de funcao com parametros*/
int checkCall(node_ptr no) 
{
	if (checkNode(no, "Call", 1)==0) return 0;
	scope* funcaoCall = getFuncScope(no->child->list[0]);
	if (funcaoCall == NULL) return 0;

	int num = countFuncParams(funcaoCall);
	if (num == -1) return 0; /*ocorreu um erro*/
	if (num != no->child->size-1)  /*Wrong number of arguments*/
	{ 
		argNumber(no->child->list[0]->linha, no->child->list[0]->coluna, no->child->list[0]->value, no->child->size-1, num);
		return 0;
	}
	if (num == 0) return 1; /* Nao tem filhos, nao e preciso comparar tipos*/
	
	/*verificar tipos de filhos*/
	int i = 0;
	variavel* aux = funcaoCall->varList->next;
	basic_type tipo1, tipo2;
	
	while (aux!=NULL && i<num) 
	{
		if (no->child->list[i+1] == NULL) break;
		
		/*Verificar se e passagem por referencia - tem de ser variavel*/
		if (strcmp(aux->flag,"varparam") == 0) 
		{
			variavel *aux2 = checkTable2(no->child->list[i+1]);
			if (aux2 == NULL || (aux2!=NULL && aux2->flag!=NULL && strcmp(aux2->flag, "constant") == 0)) 
			{
				print_error(9,no->child->list[i+1]->linha, no->child->list[i+1]->coluna, NULL, NULL, NULL, 0);
				return 0; /*variable identifier expected*/
			}

			/*verificar se variavel e do tipo esperado*/
			tipo1 = aux->tipo;
			tipo2 = aux2->tipo;
			if (tipo1 !=tipo2 && !(tipo1 == real && tipo2 == integer)) 
			{
				print_error(3,no->child->list[i+1]->linha, no->child->list[i+1]->coluna, no->child->list[0]->value, tipoStr[tipo2], tipoStr[tipo1],i+1);
				return 0;/*Incompatible type for argument i*/
			}
		}
		else 
		{
			/*verificar se expressao e do tipo certo*/
			tipo1 = aux->tipo;
			if (tipo1 == error || tipo1 == empty) return 0;
			
			tipo2 = evalExpr(no->child->list[i+1]);
			if (tipo2 == error || tipo2 == empty) return 0;
			
			if (tipo1 !=tipo2 && !(tipo1 == real && tipo2 == integer)) 
			{
				print_error(3,no->child->list[i+1]->linha, no->child->list[i+1]->coluna, no->child->list[0]->value, tipoStr[tipo2], tipoStr[tipo1],i+1);
				return 0;/*Incompatible type for argument i*/
			}
		}
		aux = aux->next; i++;
	}
	
	return 1;
}

/*tentar inserir parametro no scope da funcao*/
int checkParam(node_ptr no, char* flag, char* nodeName) 
{
	if (checkNode(no, nodeName,2)==0) return 0;

	basic_type tipo = typeName(no->child->list[no->child->size-1],0);
    if (tipo == error) return 0;
	
	
	int i;
	for (i = 0; i<no->child->size-1;i++) {
		if (insertParam (cur, no->child->list[i]->value, tipo, flag) == 0) 
        {
            print_error(6,no->child->list[i]->linha,no->child->list[i]->coluna,no->child->list[i]->value,NULL,NULL,0);
			return 0; /*Symbol already defined - ja se encontra neste scope*/
		}
	}
	return 1;
}

/*verificar writeln*/
int checkWriteLn(node_ptr no) 
{
	if (no == NULL || strcmp(no->type,"WriteLn")!=0) return 0;
	if (no->child == NULL || no->child->size == 0) return 1;
	
	int i;    
	for (i = 0; i<no->child->size; i++) 
    {
		basic_type tipo = evalExpr(no->child->list[i]);
        no->child->list[i]->tipo = tipo;
                
		if (tipo == error) return 0;
		
		if (tipo == type) /*nao pode escrever ids que identifiquem tipos*/
        {
			print_error(1,no->child->list[i]->linha,no->child->list[i]->coluna,NULL, NULL, NULL,0);
			return 0;/*cannot write values of type _type_*/
		}
	}
	return 1;
}

/*verificar valparam*/
int checkValParam(node_ptr no) 
{
	if (checkNode(no, "ValParam",2)==0) return 0;
    
	basic_type tipo = evalExpr(no->child->list[0]);
    	
    if (tipo == error) return 0;
	
	variavel *aux2 = lookupVar(no->child->list[0]->value, cur );
    
	if (aux2==NULL && cur!=programNode) aux2 = lookupVar(no->child->list[0]->value, programNode);
	
	if ((aux2!=NULL && aux2->flag!=NULL && strcmp(aux2->flag, "constant") == 0)) 
	{
		print_error(9,no->child->list[0]->linha, no->child->list[0]->coluna, NULL, NULL, NULL, 0);
		return 0;
	}
	
	if (tipo!=integer) 
	{
		print_error(5,no->child->list[0]->linha,no->child->list[0]->coluna,"val-paramstr",tipoStr[tipo],"_integer_",0);
		return 0;
	}
	
	tipo = checkTable(no->child->list[1]);
        
	if (tipo == error) 
	{
		print_error(7,no->child->list[1]->linha,no->child->list[1]->coluna,no->child->list[1]->value,NULL,NULL,0);
		return 0;
	}
	
	if (tipo!=integer) 
	{
		print_error(5,no->child->list[1]->linha,no->child->list[1]->coluna,"val-paramstr",tipoStr[tipo],"_integer_",0);
		return 0;
	}
	
	return 1;
}


basic_type evalExpr(node_ptr no) 
{
	if (no == NULL) return error;
	if (no->child == NULL || no->child->size == 0) /*terminal*/
    	{
		if (strcmp(no->type,"IntLit")==0) return integer;
		if (strcmp(no->type,"RealLit")==0) return real;
		if (strcmp(no->type,"String")==0) return string;
		if (strcmp(no->type,"Id")==0) 
        {
            
			variavel* aux3 = checkTable2(no);
			basic_type tipo = checkTable(no);
			if (aux3!=NULL && aux3->flag!=NULL && strcmp(aux3->flag,"return")==0) 
			{ //esta a chamar-se a si própria
				if(checkEmptyCall(no) == 0) return error;
				else return aux3->tipo;
			}
			else if (tipo == function) 
			{
				if(checkEmptyCall(no) == 0) return error; //Symbol not defined
				else return funcAux;
			}
			if (tipo == error) print_error(7,no->linha, no->coluna, no->value,NULL,NULL,0);
			return tipo;
		}
        return error;
	}
    
	else 
    	{			
		/*Call*/
		if (strcmp(no->type,"Call")==0) 
        	{
			if (checkCall(no) == 0) return error;
			else return funcAux;
		}
		
		/*obter tipo dos filhos*/
		basic_type tipo1, tipo2;
		if (no->child->size>0) 
        {
			tipo1 = evalExpr(no->child->list[0]);
			if (tipo1 == error) return error;
		}
		if (no->child->size>1) {
			tipo2 = evalExpr(no->child->list[1]);
			if (tipo2 == error) return error;
		}
		
		/*Reais ou inteiros com sinal*/
		if (strcmp(no->type,"Minus")==0 || strcmp(no->type,"Plus")==0) 
        {
			if (tipo1 == integer || tipo1 == real)
				return tipo1;
			else 
            {
				print_error(11,no->linha,no->coluna,no->value, tipoStr[tipo1],NULL,0);
				return error;
			}
		}
		
		/*Mod e div - so inteiros*/
		if (strcmp(no->type,"Mod")==0 || strcmp(no->type,"Div")==0) 
        	{
			if (tipo1 == integer && tipo2 == integer)
				return integer;
			else 
			{
				print_error(12,no->linha,no->coluna,no->value, tipoStr[tipo1],tipoStr[tipo2],0);
				return error;
			}
		}
		
		/*Divisao real devolve sempre real*/
		if (strcmp(no->type,"RealDiv")==0) 
		{
			if ((tipo1==integer||tipo1 == real) && (tipo2 == integer||tipo2 == real))
				return real;
			
			else 
			{
				print_error(12,no->linha,no->coluna,"/", tipoStr[tipo1],tipoStr[tipo2],0);
				return error;
			}
		}
		
		/*Soma, sub e multiplicacao - depende dos termos*/
		if (strcmp(no->type,"Add")==0||strcmp(no->type,"Sub")==0||strcmp(no->type,"Mul")==0) 
		{
			if (tipo1 == integer)
			{
				if(tipo2 == integer) return integer;
				else if (tipo2 == real) return real;
				else 
				{
					print_error(12,no->linha,no->coluna,no->value, tipoStr[tipo1],tipoStr[tipo2],0);
					return error;
				}
			}
			else if (tipo1 == real) 
			{
				if (tipo2 != real && tipo2!=integer) 
				{
					print_error(12,no->linha,no->coluna,no->value, tipoStr[tipo1],tipoStr[tipo2],0);
					return error;
				}
				else return real;
			}
			else 
			{
				print_error(12,no->linha,no->coluna,no->value, tipoStr[tipo1],tipoStr[tipo2],0);
				return error;
			}
		}

		/*Comparadores*/
		if (strcmp(no->type,"Neq")==0||strcmp(no->type,"Eq")==0||
			strcmp(no->type,"Geq")==0||strcmp(no->type,"Gt")==0||
			strcmp(no->type,"Lt")==0||strcmp(no->type,"Leq")==0) 
		{
			if (((tipo1==integer||tipo1 == real) && (tipo2 == integer||tipo2 == real) )||(tipo1 ==boolean && tipo2 == boolean))
				return boolean;
			else 
			{
				print_error(12,no->linha,no->coluna,no->value, tipoStr[tipo1],tipoStr[tipo2],0);
				return error;
			}
		}//incompatible tipes
		
		/*And, or e not*/
		if (strcmp(no->type,"And")==0||strcmp(no->type,"Or")==0) 
        	{
			if ((tipo1 == boolean && tipo2 == boolean)) return boolean;
			else 
			{
				print_error(12,no->linha,no->coluna,no->value, tipoStr[tipo1],tipoStr[tipo2],0);
				return error;
			}
		}
		
		if (strcmp(no->type,"Not")==0) 
		{
			if (tipo1 == boolean) return boolean;
			else 
			{
				print_error(11,no->linha,no->coluna,no->value, tipoStr[tipo1],NULL,0);
				return error;
			}
		}
		
		return error;
	}
}

/*tenta inserir nova variavel*/
int checkNewVariable(node_ptr no, basic_type tipo) 
{
	if ( insertVar(no->value, tipo, cur) == NULL )
    {
        print_error(6,no->linha,no->coluna,no->value,NULL,NULL,0);
        return 0;/*symbol already defined*/
    }
    
    no->tipo = tipo;

    return 1;
}

/*devolve ponteiro para nova funcao ou null se houver erro*/
int registerFunc(node_ptr no, basic_type tipo, char*flag) 
{
	cur = insertFuncDecl(no->value, tipo, programNode, flag, no->linha, no->coluna);
	if (cur == NULL) return 0;
	return 1;
}

/*devolve tipo da variavel*/
basic_type checkTable(node_ptr no) 
{
    variavel* aux = checkTable2(no);
	if (aux!=NULL) return aux->tipo;
	return error;
}

/*devolve ponteiro para variavel*/
variavel* checkTable2(node_ptr no) 
{
	if (strcmp(no->type,"Id")!=0) return NULL;
	variavel *aux2 = lookupVar(no->value, cur );
	if (aux2==NULL && cur!=programNode) aux2 = lookupVar(no->value, programNode);
	if (aux2==NULL && cur!=outer) aux2 = lookupVar(no->value, outer);
	return aux2;
}

/*devolve ponteiro, para usar com llvm*/
variavel* checkTable3(node_ptr no, scope * curLL) 
{
		if (strcmp(no->type,"Id")!=0) return NULL;
	variavel *aux2 = lookupVar(no->value, curLL );
    
    if ( strcmp("paramcount",no->value) == 0 && redParamcount )
    {
	   if (aux2==NULL && curLL!=programNode) aux2 = lookupVar(no->value, programNode);
    }
    
    else if ( strcmp("paramcount",no->value) == 0 && !redParamcount )
    {
	   if (aux2==NULL && curLL!=outer) aux2 = lookupVar(no->value, outer);
    }
        
    else
    {
        if (aux2==NULL && curLL!=programNode) aux2 = lookupVar(no->value, programNode);
        if (aux2==NULL && curLL!=outer) aux2 = lookupVar(no->value, outer);
    }
    
	return aux2;
}

variavel* boolVar (char* what)
{
	variavel *aux = lookupVar(what, outer);
	return aux;
}

basic_type typeName(node_ptr no, int flag) 
{
	if (no->value == NULL || strcmp(no->value,"")==0) return error;
	basic_type tipo = checkTable(no);
	
	if (tipo == type) 
	{
		if (compareLower(no->value, "integer") == 0) return integer;
		if (compareLower(no->value, "real") == 0) return real;
		if (compareLower(no->value, "boolean") == 0) return boolean;
	}
	
	if (tipo == empty || tipo == error) /*symbol not defined*/
		print_error(7,no->linha,no->coluna,no->value,NULL,NULL,0);
	else if (flag == 0) print_error(8,no->linha,no->coluna,NULL,NULL,NULL,0);
		/*pretendiamos tipo --> type identifier expected*/
	return error;
}



void print_error(int tipo, int line, int col, char *token, char *type, char *type2, int num) 
{
	switch (tipo) 
    	{        
		case 1: 
			printf("Line %i, col %i: Cannot write values of type _type_\n",line, col); break;
		case 2: 
			printf("Line %i, col %i: Function identifier expected\n",line, col); break;
		case 3: 
			printf("Line %i, col %i: Incompatible type for argument %i in call to function %s (got %s, expected %s)\n",line, col, num, token, type, type2); break;
		case 4: 
			printf("Line %i, col %i: Incompatible type in assigment to %s (got %s, expected %s)\n",line, col, token, type, type2); break;
		case 5: 
			printf("Line %i, col %i: Incompatible type in %s statement (got %s, expected %s)\n",line, col, token, type, type2); break;
		case 6: 
			printf("Line %i, col %i: Symbol %s already defined\n",line, col, token); break;
		case 7: 
			printf("Line %i, col %i: Symbol %s not defined\n",line, col, token); break;
		case 8: 
			printf("Line %i, col %i: Type identifier expected\n",line, col); break;
		case 9: 
			printf("Line %i, col %i: Variable identifier expected\n",line, col); break;
		case 11:
			printf("Line %i, col %i: Operator %s cannot be applied to type %s\n",line, col, token, type); break;
		case 12:
			printf("Line %i, col %i: Operator %s cannot be applied to types %s, %s\n",line, col, token, type, type2); break;
	}
}


void argNumber(int line, int col, char* token, int n1, int n2) 
{
	printf("Line %i, col %i: Wrong number of arguments in call to function %s (got %i, expected %i)\n",line, col, token, n1, n2);
}

void free_table () 
{
	freeTables(outer);
}

basic_type getFuncAux() {
	return funcAux;
}

scope* getProgramNode() {
	return programNode;
}