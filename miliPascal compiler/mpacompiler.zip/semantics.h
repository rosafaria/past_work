#include "node.h"

/*Funcao para comparar em minusculas*/
int compareLower(char*, char*);
char *toLower(char*);

/*Funcoes de verificacao*/
int checkProgram(node_ptr,int);
int checkVarPart(node_ptr);
int checkFuncPart(node_ptr);
int checkStatPart(node_ptr);
int checkVarDecl(node_ptr);
int checkFuncDecl(node_ptr);
int checkFuncDef(node_ptr);
int checkFuncDef2(node_ptr);
int checkFuncParams(node_ptr);
void print_error(int, int, int, char*, char*, char*, int);
void argNumber(int, int, char*, int, int);

//--Statements--//
int checkAssign(node_ptr);
int checkWriteLn(node_ptr);
int checkCall(node_ptr);
int checkIfElse (node_ptr);
int checkRepeat (node_ptr);
int checkStatList (node_ptr);
int checkWhile (node_ptr);
int checkValParam(node_ptr);

basic_type evalExpr(node_ptr);
basic_type typeName(node_ptr no, int flag);
int checkNode (node_ptr no, char* name, int children);

/*Funcoes do semantics que chamam funcoes do symbols*/
int registerFunc(node_ptr, basic_type, char*);
int checkNewVariable(node_ptr, basic_type);
int checkParam(node_ptr,char*,char*);
basic_type checkTable(node_ptr);
variavel *checkTable2(node_ptr);
void free_table();

/*Funcoes do symbols*/
variavel *createVar(char*, basic_type, char*, char*, scope*);
variavel *insertVar(char*, basic_type, scope*);
scope *createOuter();
scope *createFunctionTable(char*, basic_type, scope*);
scope *insertFuncDecl(char*, basic_type, scope*, char*, int, int) ;
void printTables (scope*);
void freeTables (scope*);
int insertParam (scope*, char*, basic_type, char*) ;
int countFuncParams(scope*);
variavel *lookupVar(char*, scope*);
scope* getFuncScope(node_ptr no);
scope* getParamcountScope( node_ptr no, int redefinido );

/*getters para llvm*/
basic_type getFuncAux();
variavel* boolVar (char* what);
scope* getProgramNode();
variavel *checkTable3(node_ptr, scope*);